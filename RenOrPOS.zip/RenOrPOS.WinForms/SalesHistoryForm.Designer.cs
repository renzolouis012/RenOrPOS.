﻿
namespace RenOrPOS.WinForms
{
    partial class SalesHistoryForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Panel pnlFilters;
        private System.Windows.Forms.Panel pnlDetails;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.Label lblSalesTitle;
        private System.Windows.Forms.Label lblDetailsTitle;
        private System.Windows.Forms.Label lblSummary;

        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.CheckBox chkDateFilter;

        private System.Windows.Forms.DataGridView dgvSales;
        private System.Windows.Forms.DataGridView dgvSaleItems;

        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnPrintReceipt;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.pnlHeader =
                new System.Windows.Forms.Panel();

            this.pnlFilters =
                new System.Windows.Forms.Panel();

            this.pnlDetails =
                new System.Windows.Forms.Panel();

            this.lblTitle =
                new System.Windows.Forms.Label();

            this.lblSearch =
                new System.Windows.Forms.Label();

            this.lblFrom =
                new System.Windows.Forms.Label();

            this.lblTo =
                new System.Windows.Forms.Label();

            this.lblSalesTitle =
                new System.Windows.Forms.Label();

            this.lblDetailsTitle =
                new System.Windows.Forms.Label();

            this.lblSummary =
                new System.Windows.Forms.Label();

            this.txtSearch =
                new System.Windows.Forms.TextBox();

            this.dtpFrom =
                new System.Windows.Forms.DateTimePicker();

            this.dtpTo =
                new System.Windows.Forms.DateTimePicker();

            this.chkDateFilter =
                new System.Windows.Forms.CheckBox();

            this.dgvSales =
                new System.Windows.Forms.DataGridView();

            this.dgvSaleItems =
                new System.Windows.Forms.DataGridView();

            this.btnRefresh =
                new System.Windows.Forms.Button();

            this.btnClose =
                new System.Windows.Forms.Button();

            this.btnPrintReceipt =
                new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvSales)).BeginInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvSaleItems)).BeginInit();

            this.SuspendLayout();

            // FORM
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(6F, 13F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(1180, 740);

            this.MinimumSize =
                new System.Drawing.Size(1050, 680);

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterParent;

            this.BackColor =
                System.Drawing.Color.FromArgb(245, 247, 252);

            this.Font =
                new System.Drawing.Font("Segoe UI", 10F);

            this.Name = "SalesHistoryForm";
            this.Text = "RenOrPOS - Sales History";

            // HEADER
            this.pnlHeader.Dock =
                System.Windows.Forms.DockStyle.Top;

            this.pnlHeader.Height = 75;

            this.pnlHeader.BackColor =
                System.Drawing.Color.FromArgb(25, 47, 70);

            this.lblTitle.Text =
                "RenOrPOS | Sales History";

            this.lblTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);

            this.lblTitle.ForeColor =
                System.Drawing.Color.White;

            this.lblTitle.AutoSize = true;

            this.lblTitle.Location =
                new System.Drawing.Point(22, 18);

            this.btnClose.Text = "Close";

            this.btnClose.Size =
                new System.Drawing.Size(100, 38);

            this.btnClose.Location =
                new System.Drawing.Point(1050, 18);

            this.btnClose.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnClose.Click +=
                new System.EventHandler(
                    this.btnClose_Click);

            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.btnClose);

            // FILTER PANEL
            this.pnlFilters.Location =
                new System.Drawing.Point(20, 95);

            this.pnlFilters.Size =
                new System.Drawing.Size(1140, 115);

            this.pnlFilters.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlFilters.BackColor =
                System.Drawing.Color.White;

            this.pnlFilters.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblSearch.Text =
                "Search Sale ID / Cashier";

            this.lblSearch.AutoSize = true;

            this.lblSearch.Location =
                new System.Drawing.Point(15, 12);

            this.txtSearch.Location =
                new System.Drawing.Point(18, 40);

            this.txtSearch.Size =
                new System.Drawing.Size(280, 30);

            this.lblFrom.Text = "From";
            this.lblFrom.AutoSize = true;

            this.lblFrom.Location =
                new System.Drawing.Point(320, 12);

            this.dtpFrom.Location =
                new System.Drawing.Point(320, 40);

            this.dtpFrom.Size =
                new System.Drawing.Size(175, 30);

            this.dtpFrom.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;

            this.lblTo.Text = "To";
            this.lblTo.AutoSize = true;

            this.lblTo.Location =
                new System.Drawing.Point(515, 12);

            this.dtpTo.Location =
                new System.Drawing.Point(515, 40);

            this.dtpTo.Size =
                new System.Drawing.Size(175, 30);

            this.dtpTo.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;

            this.chkDateFilter.Text = "Use Date Filter";
            this.chkDateFilter.AutoSize = true;

            this.chkDateFilter.Location =
                new System.Drawing.Point(715, 43);

            this.btnRefresh.Text = "Refresh";

            this.btnRefresh.Size =
                new System.Drawing.Size(125, 37);

            this.btnRefresh.Location =
                new System.Drawing.Point(985, 36);

            this.btnRefresh.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnRefresh.BackColor =
                System.Drawing.Color.FromArgb(85, 105, 190);

            this.btnRefresh.ForeColor =
                System.Drawing.Color.White;

            this.btnRefresh.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnRefresh.Click +=
                new System.EventHandler(
                    this.btnRefresh_Click);

            this.pnlFilters.Controls.Add(this.lblSearch);
            this.pnlFilters.Controls.Add(this.txtSearch);
            this.pnlFilters.Controls.Add(this.lblFrom);
            this.pnlFilters.Controls.Add(this.dtpFrom);
            this.pnlFilters.Controls.Add(this.lblTo);
            this.pnlFilters.Controls.Add(this.dtpTo);
            this.pnlFilters.Controls.Add(this.chkDateFilter);
            this.pnlFilters.Controls.Add(this.btnRefresh);

            // SALES TITLE
            this.lblSalesTitle.Text = "Completed Sales";

            this.lblSalesTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 14F,
                    System.Drawing.FontStyle.Bold);

            this.lblSalesTitle.AutoSize = true;

            this.lblSalesTitle.Location =
                new System.Drawing.Point(22, 224);

            // SALES GRID
            this.dgvSales.Location =
                new System.Drawing.Point(20, 260);

            this.dgvSales.Size =
                new System.Drawing.Size(1140, 210);

            this.dgvSales.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvSales.BackgroundColor =
                System.Drawing.Color.White;

            this.dgvSales.ReadOnly = true;
            this.dgvSales.AllowUserToAddRows = false;
            this.dgvSales.AllowUserToDeleteRows = false;
            this.dgvSales.MultiSelect = false;

            this.dgvSales.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode
                    .FullRowSelect;

            this.dgvSales.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode
                    .Fill;

            // DETAILS PANEL
            this.pnlDetails.Location =
                new System.Drawing.Point(20, 490);

            this.pnlDetails.Size =
                new System.Drawing.Size(1140, 225);

            this.pnlDetails.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlDetails.BackColor =
                System.Drawing.Color.White;

            this.pnlDetails.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblDetailsTitle.Text =
                "Selected Sale Details";

            this.lblDetailsTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 14F,
                    System.Drawing.FontStyle.Bold);

            this.lblDetailsTitle.AutoSize = true;

            this.lblDetailsTitle.Location =
                new System.Drawing.Point(15, 12);

            // PRINT RECEIPT BUTTON
            this.btnPrintReceipt.Text = "Print Receipt";

            this.btnPrintReceipt.Name =
                "btnPrintReceipt";

            this.btnPrintReceipt.Size =
                new System.Drawing.Size(140, 38);

            this.btnPrintReceipt.Location =
                new System.Drawing.Point(975, 10);

            this.btnPrintReceipt.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnPrintReceipt.BackColor =
                System.Drawing.Color.FromArgb(85, 105, 190);

            this.btnPrintReceipt.ForeColor =
                System.Drawing.Color.White;

            this.btnPrintReceipt.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnPrintReceipt.Click +=
                new System.EventHandler(
                    this.btnPrintReceipt_Click);

            // SALE ITEMS GRID
            this.dgvSaleItems.Location =
                new System.Drawing.Point(18, 52);

            this.dgvSaleItems.Size =
                new System.Drawing.Size(1100, 115);

            this.dgvSaleItems.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvSaleItems.BackgroundColor =
                System.Drawing.Color.White;

            this.dgvSaleItems.ReadOnly = true;
            this.dgvSaleItems.AllowUserToAddRows = false;
            this.dgvSaleItems.AllowUserToDeleteRows = false;
            this.dgvSaleItems.MultiSelect = false;

            this.dgvSaleItems.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode
                    .FullRowSelect;

            this.dgvSaleItems.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode
                    .Fill;

            // PAYMENT SUMMARY
            this.lblSummary.Text =
                "Select a sale to view its payment details.";

            this.lblSummary.AutoSize = true;

            this.lblSummary.Location =
                new System.Drawing.Point(18, 183);

            this.lblSummary.Anchor =
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Bottom;

            this.pnlDetails.Controls.Add(
                this.lblDetailsTitle);

            this.pnlDetails.Controls.Add(
                this.btnPrintReceipt);

            this.pnlDetails.Controls.Add(
                this.dgvSaleItems);

            this.pnlDetails.Controls.Add(
                this.lblSummary);

            // ADD TO FORM
            this.Controls.Add(this.pnlDetails);
            this.Controls.Add(this.dgvSales);
            this.Controls.Add(this.lblSalesTitle);
            this.Controls.Add(this.pnlFilters);
            this.Controls.Add(this.pnlHeader);

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvSales)).EndInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvSaleItems)).EndInit();

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
