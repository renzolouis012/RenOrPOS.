﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class SalesReportsForm : Form
    {
        public SalesReportsForm() : this("Admin")
        {
            // For Visual Studio Designer compatibility.
            // Dashboard should use the role constructor.
        }

        public SalesReportsForm(string role)
        {
            if (!DesignMode &&
                !string.Equals(role, "Admin",
                    StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(role, "Manager",
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new UnauthorizedAccessException(
                    "Only Admin and Manager can access Sales Reports.");
            }

            InitializeComponent();

            if (System.ComponentModel.LicenseManager.UsageMode ==
                System.ComponentModel.LicenseUsageMode.Designtime)
                return;

            dtpFrom.Value = DateTime.Today.AddDays(-30);
            dtpTo.Value = DateTime.Today;

            SetupChart();
            LoadReports();
        }

        private void SetupChart()
        {
            chartDailySales.Series.Clear();
            chartDailySales.ChartAreas.Clear();
            chartDailySales.Legends.Clear();

            ChartArea area = new ChartArea("MainArea");
            area.AxisX.Interval = 1;
            area.AxisX.MajorGrid.Enabled = false;
            area.AxisY.MajorGrid.LineColor = Color.LightGray;
            area.AxisY.LabelStyle.Format = "N0";

            chartDailySales.ChartAreas.Add(area);

            Series series = new Series("Revenue");
            series.ChartType = SeriesChartType.Column;
            series.ChartArea = "MainArea";
            series.Color = Color.FromArgb(85, 105, 190);
            series.IsValueShownAsLabel = true;
            series.LabelFormat = "N2";

            chartDailySales.Series.Add(series);
        }

        private static void AddDates(
            SqlCommand cmd,
            DateTime from,
            DateTime toExclusive)
        {
            cmd.Parameters.Add("@From", SqlDbType.DateTime2)
                .Value = from;

            cmd.Parameters.Add("@To", SqlDbType.DateTime2)
                .Value = toExclusive;
        }

        private void LoadReports()
        {
            if (dtpFrom.Value.Date > dtpTo.Value.Date)
            {
                MessageBox.Show(
                    "From Date cannot be later than To Date.");
                return;
            }

            btnGenerate.Enabled = false;
            btnRefresh.Enabled = false;

            try
            {
                DateTime from = dtpFrom.Value.Date;
                DateTime to = dtpTo.Value.Date.AddDays(1);

                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    LoadSummary(con, from, to);
                    LoadDailySales(con, from, to);
                    LoadBestSelling(con, from, to);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Sales Reports error:\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                btnGenerate.Enabled = true;
                btnRefresh.Enabled = true;
            }
        }

        private void LoadSummary(
            SqlConnection con,
            DateTime from,
            DateTime to)
        {
            string sql = @"
                SELECT
                    COUNT(*) AS Transactions,
                    COALESCE(SUM(TotalAmount), 0) AS Revenue,
                    COALESCE(AVG(TotalAmount), 0) AS AverageSale
                FROM dbo.Sales
                WHERE SaleDate >= @From AND SaleDate < @To;

                SELECT COALESCE(SUM(si.Quantity), 0) AS ItemsSold
                FROM dbo.SaleItems si
                INNER JOIN dbo.Sales s
                    ON si.SaleId = s.SaleId
                WHERE s.SaleDate >= @From AND s.SaleDate < @To;";

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                AddDates(cmd, from, to);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        lblTransactions.Text =
                            Convert.ToInt32(
                                reader["Transactions"]).ToString("N0");

                        lblRevenue.Text = "₱" +
                            Convert.ToDecimal(
                                reader["Revenue"]).ToString("N2");

                        lblAverage.Text = "₱" +
                            Convert.ToDecimal(
                                reader["AverageSale"]).ToString("N2");
                    }

                    if (reader.NextResult() && reader.Read())
                    {
                        lblItems.Text =
                            Convert.ToInt32(
                                reader["ItemsSold"]).ToString("N0");
                    }
                }
            }
        }

        private void LoadDailySales(
            SqlConnection con,
            DateTime from,
            DateTime to)
        {
            string sql = @"
                SELECT
                    CAST(SaleDate AS DATE) AS SaleDay,
                    COUNT(*) AS Transactions,
                    SUM(TotalAmount) AS Revenue
                FROM dbo.Sales
                WHERE SaleDate >= @From AND SaleDate < @To
                GROUP BY CAST(SaleDate AS DATE)
                ORDER BY SaleDay;";

            DataTable table = new DataTable();

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                AddDates(cmd, from, to);

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }

            dgvDailySales.DataSource = table;

            if (dgvDailySales.Columns.Contains("SaleDay"))
            {
                dgvDailySales.Columns["SaleDay"].HeaderText = "Date";
                dgvDailySales.Columns["SaleDay"]
                    .DefaultCellStyle.Format = "MMM dd, yyyy";
            }

            if (dgvDailySales.Columns.Contains("Revenue"))
            {
                dgvDailySales.Columns["Revenue"]
                    .DefaultCellStyle.Format = "N2";
            }

            chartDailySales.Series["Revenue"].Points.Clear();

            foreach (DataRow row in table.Rows)
            {
                DateTime day = Convert.ToDateTime(row["SaleDay"]);
                decimal revenue =
                    Convert.ToDecimal(row["Revenue"]);

                chartDailySales.Series["Revenue"]
                    .Points.AddXY(
                        day.ToString("MMM dd, yyyy"),
                        revenue);
            }
        }

        private void LoadBestSelling(
            SqlConnection con,
            DateTime from,
            DateTime to)
        {
            string sql = @"
                SELECT
                    p.Name AS ProductName,
                    SUM(si.Quantity) AS UnitsSold,
                    SUM(si.Quantity * si.UnitPrice)
                        AS Revenue
                FROM dbo.SaleItems si
                INNER JOIN dbo.Sales s
                    ON si.SaleId = s.SaleId
                INNER JOIN dbo.Products p
                    ON si.ProductId = p.ProductId
                WHERE s.SaleDate >= @From AND s.SaleDate < @To
                GROUP BY p.ProductId, p.Name
                ORDER BY UnitsSold DESC, Revenue DESC;";

            DataTable table = new DataTable();

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                AddDates(cmd, from, to);

                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }

            dgvBestSelling.DataSource = table;

            if (dgvBestSelling.Columns.Contains("ProductName"))
                dgvBestSelling.Columns["ProductName"]
                    .HeaderText = "Product Name";

            if (dgvBestSelling.Columns.Contains("UnitsSold"))
                dgvBestSelling.Columns["UnitsSold"]
                    .HeaderText = "Units Sold";

            if (dgvBestSelling.Columns.Contains("Revenue"))
                dgvBestSelling.Columns["Revenue"]
                    .DefaultCellStyle.Format = "N2";
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            LoadReports();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadReports();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
