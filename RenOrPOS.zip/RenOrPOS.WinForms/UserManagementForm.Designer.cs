﻿
namespace RenOrPOS.WinForms
{
    partial class UserManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // HEADER
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubtitle;

        // USER INFORMATION
        private System.Windows.Forms.GroupBox grpUserInfo;

        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblRole;

        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.ComboBox cmbRole;

        // BUTTONS
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDeactivate;
        private System.Windows.Forms.Button btnActivate;
        private System.Windows.Forms.Button btnResetPassword;

        // REGISTERED USERS
        private System.Windows.Forms.Label lblUsers;
        private System.Windows.Forms.DataGridView dgvUsers;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">
        /// true if managed resources should be disposed;
        /// otherwise, false.
        /// </param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();

            this.grpUserInfo = new System.Windows.Forms.GroupBox();

            this.lblUsername = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();

            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.cmbRole = new System.Windows.Forms.ComboBox();

            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDeactivate = new System.Windows.Forms.Button();
            this.btnActivate = new System.Windows.Forms.Button();
            this.btnResetPassword = new System.Windows.Forms.Button();

            this.lblUsers = new System.Windows.Forms.Label();
            this.dgvUsers = new System.Windows.Forms.DataGridView();

            this.pnlHeader.SuspendLayout();
            this.grpUserInfo.SuspendLayout();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvUsers)).BeginInit();

            this.SuspendLayout();

            // =====================================
            // FORM SETTINGS
            // =====================================
            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(1050, 720);

            this.Name = "UserManagementForm";

            this.Text = "RenOrPOS - User Management";

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.FormBorderStyle =
                System.Windows.Forms.FormBorderStyle.FixedSingle;

            this.MaximizeBox = false;

            this.BackColor =
                System.Drawing.Color.FromArgb(245, 244, 250);

            this.Font = new System.Drawing.Font(
                "Segoe UI", 10F);

            // =====================================
            // HEADER PANEL
            // =====================================
            this.pnlHeader.Name = "pnlHeader";

            this.pnlHeader.Dock =
                System.Windows.Forms.DockStyle.Top;

            this.pnlHeader.Height = 75;

            this.pnlHeader.BackColor =
                System.Drawing.Color.FromArgb(81, 71, 157);

            // TITLE
            this.lblTitle.Name = "lblTitle";

            this.lblTitle.AutoSize = true;

            this.lblTitle.Location =
                new System.Drawing.Point(25, 10);

            this.lblTitle.Text = "USER MANAGEMENT";

            this.lblTitle.Font = new System.Drawing.Font(
                "Segoe UI",
                17F,
                System.Drawing.FontStyle.Bold);

            this.lblTitle.ForeColor =
                System.Drawing.Color.White;

            // SUBTITLE
            this.lblSubtitle.Name = "lblSubtitle";

            this.lblSubtitle.AutoSize = true;

            this.lblSubtitle.Location =
                new System.Drawing.Point(28, 47);

            this.lblSubtitle.Text =
                "RENORPOS - ADMIN CONTROL PANEL";

            this.lblSubtitle.Font =
                new System.Drawing.Font("Segoe UI", 9F);

            this.lblSubtitle.ForeColor =
                System.Drawing.Color.FromArgb(227, 223, 249);

            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.lblSubtitle);

            // =====================================
            // USER INFORMATION GROUPBOX
            // =====================================
            this.grpUserInfo.Name = "grpUserInfo";

            this.grpUserInfo.Text = "User Information";

            this.grpUserInfo.Location =
                new System.Drawing.Point(25, 95);

            this.grpUserInfo.Size =
                new System.Drawing.Size(1000, 285);

            this.grpUserInfo.BackColor =
                System.Drawing.Color.White;

            this.grpUserInfo.Font = new System.Drawing.Font(
                "Segoe UI",
                10F,
                System.Drawing.FontStyle.Bold);

            // =====================================
            // USERNAME
            // =====================================
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.AutoSize = true;

            this.lblUsername.Location =
                new System.Drawing.Point(25, 35);

            this.lblUsername.Text = "Username";

            this.txtUsername.Name = "txtUsername";

            this.txtUsername.Location =
                new System.Drawing.Point(25, 60);

            this.txtUsername.Size =
                new System.Drawing.Size(450, 30);

            this.txtUsername.MaxLength = 50;

            // =====================================
            // FULL NAME
            // =====================================
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.AutoSize = true;

            this.lblFullName.Location =
                new System.Drawing.Point(515, 35);

            this.lblFullName.Text = "Full Name";

            this.txtFullName.Name = "txtFullName";

            this.txtFullName.Location =
                new System.Drawing.Point(515, 60);

            this.txtFullName.Size =
                new System.Drawing.Size(450, 30);

            this.txtFullName.MaxLength = 100;

            // =====================================
            // PASSWORD
            // =====================================
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.AutoSize = true;

            this.lblPassword.Location =
                new System.Drawing.Point(25, 105);

            this.lblPassword.Text =
                "Password / New Password";

            this.txtPassword.Name = "txtPassword";

            this.txtPassword.Location =
                new System.Drawing.Point(25, 130);

            this.txtPassword.Size =
                new System.Drawing.Size(450, 30);

            this.txtPassword.UseSystemPasswordChar = true;

            // =====================================
            // ROLE COMBOBOX
            // =====================================
            this.lblRole.Name = "lblRole";
            this.lblRole.AutoSize = true;

            this.lblRole.Location =
                new System.Drawing.Point(515, 105);

            this.lblRole.Text = "User Role";

            this.cmbRole.Name = "cmbRole";

            this.cmbRole.Location =
                new System.Drawing.Point(515, 130);

            this.cmbRole.Size =
                new System.Drawing.Size(450, 30);

            this.cmbRole.DropDownStyle =
                System.Windows.Forms.ComboBoxStyle.DropDownList;

            // =====================================
            // ADD USER BUTTON
            // =====================================
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Text = "Add User";

            this.btnAdd.Location =
                new System.Drawing.Point(25, 185);

            this.btnAdd.Size =
                new System.Drawing.Size(145, 42);

            this.btnAdd.BackColor =
                System.Drawing.Color.FromArgb(81, 71, 157);

            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.UseVisualStyleBackColor = false;

            // =====================================
            // UPDATE USER BUTTON
            // =====================================
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Text = "Update User";

            this.btnUpdate.Location =
                new System.Drawing.Point(185, 185);

            this.btnUpdate.Size =
                new System.Drawing.Size(145, 42);

            this.btnUpdate.BackColor =
                System.Drawing.Color.FromArgb(22, 141, 145);

            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.UseVisualStyleBackColor = false;

            // =====================================
            // CLEAR BUTTON
            // =====================================
            this.btnClear.Name = "btnClear";
            this.btnClear.Text = "Clear Fields";

            this.btnClear.Location =
                new System.Drawing.Point(345, 185);

            this.btnClear.Size =
                new System.Drawing.Size(145, 42);

            this.btnClear.BackColor =
                System.Drawing.Color.FromArgb(146, 145, 154);

            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.UseVisualStyleBackColor = false;

            // =====================================
            // DEACTIVATE BUTTON
            // =====================================
            this.btnDeactivate.Name = "btnDeactivate";
            this.btnDeactivate.Text = "Deactivate";

            this.btnDeactivate.Location =
                new System.Drawing.Point(505, 185);

            this.btnDeactivate.Size =
                new System.Drawing.Size(145, 42);

            this.btnDeactivate.BackColor =
                System.Drawing.Color.FromArgb(198, 75, 89);

            this.btnDeactivate.ForeColor = System.Drawing.Color.White;
            this.btnDeactivate.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnDeactivate.FlatAppearance.BorderSize = 0;
            this.btnDeactivate.UseVisualStyleBackColor = false;

            // =====================================
            // ACTIVATE BUTTON
            // =====================================
            this.btnActivate.Name = "btnActivate";
            this.btnActivate.Text = "Activate";

            this.btnActivate.Location =
                new System.Drawing.Point(665, 185);

            this.btnActivate.Size =
                new System.Drawing.Size(145, 42);

            this.btnActivate.BackColor =
                System.Drawing.Color.FromArgb(36, 134, 95);

            this.btnActivate.ForeColor = System.Drawing.Color.White;
            this.btnActivate.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnActivate.FlatAppearance.BorderSize = 0;
            this.btnActivate.UseVisualStyleBackColor = false;

            // =====================================
            // RESET PASSWORD BUTTON
            // =====================================
            this.btnResetPassword.Name = "btnResetPassword";
            this.btnResetPassword.Text = "Reset Password";

            this.btnResetPassword.Location =
                new System.Drawing.Point(825, 185);

            this.btnResetPassword.Size =
                new System.Drawing.Size(145, 42);

            this.btnResetPassword.BackColor =
                System.Drawing.Color.FromArgb(192, 139, 56);

            this.btnResetPassword.ForeColor = System.Drawing.Color.White;
            this.btnResetPassword.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;
            this.btnResetPassword.FlatAppearance.BorderSize = 0;
            this.btnResetPassword.UseVisualStyleBackColor = false;

            // =====================================
            // ADD CONTROLS TO GROUPBOX
            // =====================================
            this.grpUserInfo.Controls.Add(this.lblUsername);
            this.grpUserInfo.Controls.Add(this.lblFullName);
            this.grpUserInfo.Controls.Add(this.lblPassword);
            this.grpUserInfo.Controls.Add(this.lblRole);

            this.grpUserInfo.Controls.Add(this.txtUsername);
            this.grpUserInfo.Controls.Add(this.txtFullName);
            this.grpUserInfo.Controls.Add(this.txtPassword);
            this.grpUserInfo.Controls.Add(this.cmbRole);

            this.grpUserInfo.Controls.Add(this.btnAdd);
            this.grpUserInfo.Controls.Add(this.btnUpdate);
            this.grpUserInfo.Controls.Add(this.btnClear);

            this.grpUserInfo.Controls.Add(this.btnDeactivate);
            this.grpUserInfo.Controls.Add(this.btnActivate);
            this.grpUserInfo.Controls.Add(this.btnResetPassword);

            // =====================================
            // REGISTERED USERS LABEL
            // =====================================
            this.lblUsers.Name = "lblUsers";

            this.lblUsers.Text = "Registered Users";

            this.lblUsers.AutoSize = true;

            this.lblUsers.Location =
                new System.Drawing.Point(25, 400);

            this.lblUsers.Font = new System.Drawing.Font(
                "Segoe UI",
                12F,
                System.Drawing.FontStyle.Bold);

            this.lblUsers.ForeColor =
                System.Drawing.Color.FromArgb(49, 43, 97);

            // =====================================
            // DATAGRIDVIEW
            // =====================================
            this.dgvUsers.Name = "dgvUsers";

            this.dgvUsers.Location =
                new System.Drawing.Point(25, 435);

            this.dgvUsers.Size =
                new System.Drawing.Size(1000, 250);

            this.dgvUsers.BackgroundColor =
                System.Drawing.Color.White;

            this.dgvUsers.ReadOnly = true;

            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;

            this.dgvUsers.MultiSelect = false;

            this.dgvUsers.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

            this.dgvUsers.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.dgvUsers.RowHeadersVisible = false;

            this.dgvUsers.EnableHeadersVisualStyles = false;

            this.dgvUsers.ColumnHeadersDefaultCellStyle.BackColor =
                System.Drawing.Color.FromArgb(81, 71, 157);

            this.dgvUsers.ColumnHeadersDefaultCellStyle.ForeColor =
                System.Drawing.Color.White;

            this.dgvUsers.ColumnHeadersDefaultCellStyle.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    9F,
                    System.Drawing.FontStyle.Bold);

            this.dgvUsers.ColumnHeadersHeight = 35;

            this.dgvUsers.DefaultCellStyle.SelectionBackColor =
                System.Drawing.Color.FromArgb(225, 221, 245);

            this.dgvUsers.DefaultCellStyle.SelectionForeColor =
                System.Drawing.Color.Black;

            // =====================================
            // ADD CONTROLS TO FORM
            // =====================================
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.grpUserInfo);
            this.Controls.Add(this.lblUsers);
            this.Controls.Add(this.dgvUsers);

            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();

            this.grpUserInfo.ResumeLayout(false);
            this.grpUserInfo.PerformLayout();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvUsers)).EndInit();

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
