﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class InventoryForm : Form
    {
        private int selectedProductId = 0;

        public InventoryForm()
        {
            InitializeComponent();

            // Connect events programmatically
            btnAdd.Click += btnAdd_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            btnClear.Click += btnClear_Click;
            dgvProducts.CellClick += dgvProducts_CellClick;

            LoadCategories();
            LoadProducts();
            ClearFields();
        }

        // ==========================================
        // LOAD PRODUCTS
        // ==========================================
        private void LoadProducts()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_Product_List", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    DataTable dt = new DataTable();

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }

                    dgvProducts.DataSource = dt;

                    if (dgvProducts.Columns.Contains("ProductId"))
                        dgvProducts.Columns["ProductId"].Visible = false;

                    if (dgvProducts.Columns.Contains("CategoryId"))
                        dgvProducts.Columns["CategoryId"].Visible = false;

                    if (dgvProducts.Columns.Contains("IsActive"))
                        dgvProducts.Columns["IsActive"].Visible = false;

                    dgvProducts.ClearSelection();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to load products: " + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // LOAD CATEGORIES
        // ==========================================
        private void LoadCategories()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    string query = @"
                        SELECT CategoryId, CategoryName
                        FROM dbo.Categories
                        WHERE IsActive = 1
                        ORDER BY CategoryName";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(query, con))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        cmbCategory.DisplayMember = "CategoryName";
                        cmbCategory.ValueMember = "CategoryId";
                        cmbCategory.DataSource = dt;
                        cmbCategory.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to load categories: " + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // VALIDATE PRODUCT FIELDS
        // ==========================================
        private bool ValidateProduct(
            out decimal price,
            out decimal cost,
            out int stock,
            out int reorder)
        {
            price = 0;
            cost = 0;
            stock = 0;
            reorder = 0;

            if (string.IsNullOrWhiteSpace(txtSku.Text) ||
                string.IsNullOrWhiteSpace(txtProductName.Text) ||
                cmbCategory.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(txtPrice.Text) ||
                string.IsNullOrWhiteSpace(txtCost.Text) ||
                string.IsNullOrWhiteSpace(txtStock.Text) ||
                string.IsNullOrWhiteSpace(txtReorderLevel.Text))
            {
                MessageBox.Show(
                    "Please complete all required fields.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtPrice.Text, out price) ||
                !decimal.TryParse(txtCost.Text, out cost) ||
                !int.TryParse(txtStock.Text, out stock) ||
                !int.TryParse(txtReorderLevel.Text, out reorder))
            {
                MessageBox.Show(
                    "Enter valid numeric values for price, cost, stock, and reorder level.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }

            if (price < 0 || cost < 0 ||
                stock < 0 || reorder < 0)
            {
                MessageBox.Show(
                    "Numeric values cannot be negative.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        // ==========================================
        // ADD PRODUCT
        // ==========================================
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateProduct(
                out decimal price,
                out decimal cost,
                out int stock,
                out int reorder))
                return;

            if (MessageBox.Show(
                "Are you sure you want to add this product?",
                "Confirm Add",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_Product_Insert", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    AddProductParameters(
                        cmd, price, cost, stock, reorder);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "Product added successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to add product: " + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // UPDATE PRODUCT
        // ==========================================
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show(
                    "Please select a product first.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (!ValidateProduct(
                out decimal price,
                out decimal cost,
                out int stock,
                out int reorder))
                return;

            if (MessageBox.Show(
                "Are you sure you want to update this product?",
                "Confirm Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_Product_Update", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@ProductId", SqlDbType.Int).Value =
                        selectedProductId;

                    AddProductParameters(
                        cmd, price, cost, stock, reorder);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "Product updated successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to update product: " + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // DELETE PRODUCT (SOFT DELETE)
        // ==========================================
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show(
                    "Please select a product first.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show(
                "Are you sure you want to delete this product?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_Product_Delete", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@ProductId", SqlDbType.Int).Value =
                        selectedProductId;

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "Product deleted successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to delete product: " + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==========================================
        // SHARED SQL PARAMETERS
        // ==========================================
        private void AddProductParameters(
            SqlCommand cmd,
            decimal price,
            decimal cost,
            int stock,
            int reorder)
        {
            cmd.Parameters.Add(
                "@Sku", SqlDbType.VarChar, 50).Value =
                txtSku.Text.Trim();

            cmd.Parameters.Add(
                "@Barcode", SqlDbType.VarChar, 100).Value =
                string.IsNullOrWhiteSpace(txtBarcode.Text)
                    ? (object)DBNull.Value
                    : txtBarcode.Text.Trim();

            cmd.Parameters.Add(
                "@Name", SqlDbType.NVarChar, 200).Value =
                txtProductName.Text.Trim();

            cmd.Parameters.Add(
                "@CategoryId", SqlDbType.Int).Value =
                Convert.ToInt32(cmbCategory.SelectedValue);

            SqlParameter priceParam =
                cmd.Parameters.Add(
                    "@Price", SqlDbType.Decimal);
            priceParam.Precision = 18;
            priceParam.Scale = 2;
            priceParam.Value = price;

            SqlParameter costParam =
                cmd.Parameters.Add(
                    "@Cost", SqlDbType.Decimal);
            costParam.Precision = 18;
            costParam.Scale = 2;
            costParam.Value = cost;

            cmd.Parameters.Add(
                "@StockQty", SqlDbType.Int).Value = stock;

            cmd.Parameters.Add(
                "@ReorderLevel", SqlDbType.Int).Value = reorder;
        }

        // ==========================================
        // SELECT PRODUCT FROM DATAGRIDVIEW
        // ==========================================
        private void dgvProducts_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row =
                dgvProducts.Rows[e.RowIndex];

            if (row.IsNewRow)
                return;

            try
            {
                selectedProductId =
                    Convert.ToInt32(row.Cells["ProductId"].Value);

                txtSku.Text =
                    Convert.ToString(row.Cells["Sku"].Value);

                txtBarcode.Text =
                    Convert.ToString(row.Cells["Barcode"].Value);

                txtProductName.Text =
                    Convert.ToString(row.Cells["Name"].Value);

                cmbCategory.SelectedValue =
                    Convert.ToInt32(row.Cells["CategoryId"].Value);

                txtPrice.Text =
                    Convert.ToString(row.Cells["Price"].Value);

                txtCost.Text =
                    Convert.ToString(row.Cells["Cost"].Value);

                txtStock.Text =
                    Convert.ToString(row.Cells["StockQty"].Value);

                txtReorderLevel.Text =
                    Convert.ToString(row.Cells["ReorderLevel"].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to select product: " + ex.Message);
            }
        }

        // ==========================================
        // CLEAR FIELDS
        // ==========================================
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            selectedProductId = 0;

            txtSku.Clear();
            txtBarcode.Clear();
            txtProductName.Clear();
            txtPrice.Clear();
            txtCost.Clear();
            txtStock.Clear();
            txtReorderLevel.Clear();

            cmbCategory.SelectedIndex = -1;

            dgvProducts.ClearSelection();

            txtSku.Focus();
        }

        private void cmbCategory_SelectedIndexChanged(
    object sender, EventArgs e)
        {
            // Empty event handler
        }

    } // End of Inve
}

