﻿
namespace RenOrPOS.WinForms
{
    partial class SalesReportsForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Panel pnlFilters;
        private System.Windows.Forms.Panel pnlMetrics;
        private System.Windows.Forms.Panel pnlDaily;
        private System.Windows.Forms.Panel pnlProducts;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.Label lblTo;

        private System.Windows.Forms.Label lblRevenueCaption;
        private System.Windows.Forms.Label lblTransactionsCaption;
        private System.Windows.Forms.Label lblItemsCaption;
        private System.Windows.Forms.Label lblAverageCaption;

        private System.Windows.Forms.Label lblRevenue;
        private System.Windows.Forms.Label lblTransactions;
        private System.Windows.Forms.Label lblItems;
        private System.Windows.Forms.Label lblAverage;

        private System.Windows.Forms.Label lblDailyTitle;
        private System.Windows.Forms.Label lblProductsTitle;

        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.DateTimePicker dtpTo;

        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnClose;

        private System.Windows.Forms.DataGridView dgvDailySales;
        private System.Windows.Forms.DataGridView dgvBestSelling;

        private System.Windows.Forms.DataVisualization.Charting.Chart
            chartDailySales;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pnlFilters = new System.Windows.Forms.Panel();
            this.pnlMetrics = new System.Windows.Forms.Panel();
            this.pnlDaily = new System.Windows.Forms.Panel();
            this.pnlProducts = new System.Windows.Forms.Panel();

            this.lblTitle = new System.Windows.Forms.Label();
            this.lblFrom = new System.Windows.Forms.Label();
            this.lblTo = new System.Windows.Forms.Label();

            this.lblRevenueCaption = new System.Windows.Forms.Label();
            this.lblTransactionsCaption = new System.Windows.Forms.Label();
            this.lblItemsCaption = new System.Windows.Forms.Label();
            this.lblAverageCaption = new System.Windows.Forms.Label();

            this.lblRevenue = new System.Windows.Forms.Label();
            this.lblTransactions = new System.Windows.Forms.Label();
            this.lblItems = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();

            this.lblDailyTitle = new System.Windows.Forms.Label();
            this.lblProductsTitle = new System.Windows.Forms.Label();

            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();

            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();

            this.dgvDailySales =
                new System.Windows.Forms.DataGridView();

            this.dgvBestSelling =
                new System.Windows.Forms.DataGridView();

            this.chartDailySales =
                new System.Windows.Forms.DataVisualization.Charting.Chart();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvDailySales)).BeginInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvBestSelling)).BeginInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.chartDailySales)).BeginInit();

            this.pnlHeader.SuspendLayout();
            this.pnlFilters.SuspendLayout();
            this.pnlMetrics.SuspendLayout();
            this.pnlDaily.SuspendLayout();
            this.pnlProducts.SuspendLayout();
            this.SuspendLayout();

            // FORM
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(6F, 13F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(1200, 760);

            this.MinimumSize =
                new System.Drawing.Size(950, 650);

            this.FormBorderStyle =
                System.Windows.Forms.FormBorderStyle.Sizable;

            this.ControlBox = true;
            this.MinimizeBox = true;
            this.MaximizeBox = true;

            this.WindowState =
                System.Windows.Forms.FormWindowState.Normal;

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.BackColor =
                System.Drawing.Color.FromArgb(245, 247, 252);

            this.Font =
                new System.Drawing.Font("Segoe UI", 10F);

            this.Name = "SalesReportsForm";
            this.Text = "RenOrPOS - Sales Reports";

            // HEADER
            this.pnlHeader.Dock =
                System.Windows.Forms.DockStyle.Top;

            this.pnlHeader.Height = 75;

            this.pnlHeader.BackColor =
                System.Drawing.Color.FromArgb(25, 47, 70);

            this.lblTitle.AutoSize = true;
            this.lblTitle.Text = "RenOrPOS | Sales Reports";

            this.lblTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);

            this.lblTitle.ForeColor =
                System.Drawing.Color.White;

            this.lblTitle.Location =
                new System.Drawing.Point(22, 18);

            this.btnClose.Name = "btnClose";
            this.btnClose.Text = "Close";

            this.btnClose.Size =
                new System.Drawing.Size(100, 38);

            this.btnClose.Location =
                new System.Drawing.Point(1070, 18);

            this.btnClose.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnClose.Click +=
                new System.EventHandler(this.btnClose_Click);

            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.btnClose);

            // FILTER PANEL
            this.pnlFilters.Location =
                new System.Drawing.Point(20, 95);

            this.pnlFilters.Size =
                new System.Drawing.Size(1160, 90);

            this.pnlFilters.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlFilters.BackColor =
                System.Drawing.Color.White;

            this.pnlFilters.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblFrom.AutoSize = true;
            this.lblFrom.Text = "From Date";

            this.lblFrom.Location =
                new System.Drawing.Point(20, 12);

            this.dtpFrom.Location =
                new System.Drawing.Point(20, 40);

            this.dtpFrom.Size =
                new System.Drawing.Size(200, 30);

            this.dtpFrom.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;

            this.lblTo.AutoSize = true;
            this.lblTo.Text = "To Date";

            this.lblTo.Location =
                new System.Drawing.Point(245, 12);

            this.dtpTo.Location =
                new System.Drawing.Point(245, 40);

            this.dtpTo.Size =
                new System.Drawing.Size(200, 30);

            this.dtpTo.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;

            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Text = "Generate Report";

            this.btnGenerate.Location =
                new System.Drawing.Point(470, 36);

            this.btnGenerate.Size =
                new System.Drawing.Size(170, 38);

            this.btnGenerate.BackColor =
                System.Drawing.Color.FromArgb(85, 105, 190);

            this.btnGenerate.ForeColor =
                System.Drawing.Color.White;

            this.btnGenerate.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnGenerate.Click +=
                new System.EventHandler(this.btnGenerate_Click);

            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Text = "Refresh";

            this.btnRefresh.Location =
                new System.Drawing.Point(660, 36);

            this.btnRefresh.Size =
                new System.Drawing.Size(120, 38);

            this.btnRefresh.Click +=
                new System.EventHandler(this.btnRefresh_Click);

            this.pnlFilters.Controls.Add(this.lblFrom);
            this.pnlFilters.Controls.Add(this.dtpFrom);
            this.pnlFilters.Controls.Add(this.lblTo);
            this.pnlFilters.Controls.Add(this.dtpTo);
            this.pnlFilters.Controls.Add(this.btnGenerate);
            this.pnlFilters.Controls.Add(this.btnRefresh);

            // METRICS PANEL
            this.pnlMetrics.Location =
                new System.Drawing.Point(20, 205);

            this.pnlMetrics.Size =
                new System.Drawing.Size(1160, 125);

            this.pnlMetrics.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlMetrics.BackColor =
                System.Drawing.Color.White;

            this.pnlMetrics.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            // REVENUE
            this.lblRevenueCaption.Text = "TOTAL REVENUE";
            this.lblRevenueCaption.AutoSize = true;
            this.lblRevenueCaption.Location =
                new System.Drawing.Point(25, 18);

            this.lblRevenue.Text = "₱0.00";
            this.lblRevenue.AutoSize = true;
            this.lblRevenue.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);
            this.lblRevenue.Location =
                new System.Drawing.Point(25, 55);

            // TRANSACTIONS
            this.lblTransactionsCaption.Text = "TRANSACTIONS";
            this.lblTransactionsCaption.AutoSize = true;
            this.lblTransactionsCaption.Location =
                new System.Drawing.Point(300, 18);

            this.lblTransactions.Text = "0";
            this.lblTransactions.AutoSize = true;
            this.lblTransactions.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);
            this.lblTransactions.Location =
                new System.Drawing.Point(300, 55);

            // ITEMS SOLD
            this.lblItemsCaption.Text = "ITEMS SOLD";
            this.lblItemsCaption.AutoSize = true;
            this.lblItemsCaption.Location =
                new System.Drawing.Point(575, 18);

            this.lblItems.Text = "0";
            this.lblItems.AutoSize = true;
            this.lblItems.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);
            this.lblItems.Location =
                new System.Drawing.Point(575, 55);

            // AVERAGE SALE
            this.lblAverageCaption.Text = "AVERAGE SALE";
            this.lblAverageCaption.AutoSize = true;
            this.lblAverageCaption.Location =
                new System.Drawing.Point(850, 18);

            this.lblAverage.Text = "₱0.00";
            this.lblAverage.AutoSize = true;
            this.lblAverage.Font =
                new System.Drawing.Font(
                    "Segoe UI", 20F,
                    System.Drawing.FontStyle.Bold);
            this.lblAverage.Location =
                new System.Drawing.Point(850, 55);

            this.pnlMetrics.Controls.Add(this.lblRevenueCaption);
            this.pnlMetrics.Controls.Add(this.lblRevenue);
            this.pnlMetrics.Controls.Add(this.lblTransactionsCaption);
            this.pnlMetrics.Controls.Add(this.lblTransactions);
            this.pnlMetrics.Controls.Add(this.lblItemsCaption);
            this.pnlMetrics.Controls.Add(this.lblItems);
            this.pnlMetrics.Controls.Add(this.lblAverageCaption);
            this.pnlMetrics.Controls.Add(this.lblAverage);

            // DAILY SALES PANEL
            this.pnlDaily.Location =
                new System.Drawing.Point(20, 350);

            this.pnlDaily.Size =
                new System.Drawing.Size(1160, 205);

            this.pnlDaily.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlDaily.BackColor =
                System.Drawing.Color.White;

            this.pnlDaily.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblDailyTitle.Text = "Daily Sales Revenue";
            this.lblDailyTitle.AutoSize = true;
            this.lblDailyTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 14F,
                    System.Drawing.FontStyle.Bold);

            this.lblDailyTitle.Location =
                new System.Drawing.Point(15, 10);

            this.chartDailySales.Location =
                new System.Drawing.Point(18, 45);

            this.chartDailySales.Size =
                new System.Drawing.Size(700, 145);

            this.chartDailySales.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvDailySales.Location =
                new System.Drawing.Point(735, 45);

            this.dgvDailySales.Size =
                new System.Drawing.Size(405, 145);

            this.dgvDailySales.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvDailySales.ReadOnly = true;
            this.dgvDailySales.AllowUserToAddRows = false;
            this.dgvDailySales.AllowUserToDeleteRows = false;
            this.dgvDailySales.RowHeadersVisible = false;

            this.dgvDailySales.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.dgvDailySales.BackgroundColor =
                System.Drawing.Color.White;

            this.pnlDaily.Controls.Add(this.lblDailyTitle);
            this.pnlDaily.Controls.Add(this.chartDailySales);
            this.pnlDaily.Controls.Add(this.dgvDailySales);

            // BEST SELLING PRODUCTS PANEL
            this.pnlProducts.Location =
                new System.Drawing.Point(20, 575);

            this.pnlProducts.Size =
                new System.Drawing.Size(1160, 160);

            this.pnlProducts.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlProducts.BackColor =
                System.Drawing.Color.White;

            this.pnlProducts.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblProductsTitle.Text = "Best-Selling Products";
            this.lblProductsTitle.AutoSize = true;
            this.lblProductsTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 14F,
                    System.Drawing.FontStyle.Bold);

            this.lblProductsTitle.Location =
                new System.Drawing.Point(15, 10);

            this.dgvBestSelling.Location =
                new System.Drawing.Point(18, 45);

            this.dgvBestSelling.Size =
                new System.Drawing.Size(1120, 100);

            this.dgvBestSelling.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvBestSelling.ReadOnly = true;
            this.dgvBestSelling.AllowUserToAddRows = false;
            this.dgvBestSelling.AllowUserToDeleteRows = false;
            this.dgvBestSelling.RowHeadersVisible = false;

            this.dgvBestSelling.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.dgvBestSelling.BackgroundColor =
                System.Drawing.Color.White;

            this.pnlProducts.Controls.Add(this.lblProductsTitle);
            this.pnlProducts.Controls.Add(this.dgvBestSelling);

            // ADD PANELS
            this.Controls.Add(this.pnlProducts);
            this.Controls.Add(this.pnlDaily);
            this.Controls.Add(this.pnlMetrics);
            this.Controls.Add(this.pnlFilters);
            this.Controls.Add(this.pnlHeader);

            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlFilters.ResumeLayout(false);
            this.pnlFilters.PerformLayout();
            this.pnlMetrics.ResumeLayout(false);
            this.pnlMetrics.PerformLayout();
            this.pnlDaily.ResumeLayout(false);
            this.pnlDaily.PerformLayout();
            this.pnlProducts.ResumeLayout(false);
            this.pnlProducts.PerformLayout();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvDailySales)).EndInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvBestSelling)).EndInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.chartDailySales)).EndInit();

            this.ResumeLayout(false);
        }

        #endregion
    }
}
