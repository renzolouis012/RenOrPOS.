﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class POSForm : Form
    {
        private readonly int currentUserId;
        private DataTable productsTable;

        private readonly List<CartItem> cart =
            new List<CartItem>();

        private class CartItem
        {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public int Quantity { get; set; }
            public decimal UnitPrice { get; set; }

            public decimal Subtotal
            {
                get { return Quantity * UnitPrice; }
            }
        }

        public POSForm(int userId)
        {
            if (userId <= 0)
                throw new ArgumentException(
                    "Invalid authenticated user ID.");

            currentUserId = userId;

            InitializeComponent();

            dgvProducts.AutoGenerateColumns = true;
            dgvCart.AutoGenerateColumns = true;

            txtSearch.TextChanged +=
                txtSearch_TextChanged;

            txtAmountPaid.TextChanged +=
                txtAmountPaid_TextChanged;

            LoadProducts();
            RefreshCart();
        }

        // =========================================
        // LOAD PRODUCTS
        // =========================================
        private void LoadProducts()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    string query = @"
                        SELECT
                            ProductId,
                            Name AS ProductName,
                            Price,
                            StockQty AS StockQuantity
                        FROM dbo.Products
                        WHERE IsActive = 1
                          AND StockQty > 0
                        ORDER BY Name";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(query, con))
                    {
                        productsTable = new DataTable();
                        adapter.Fill(productsTable);

                        dgvProducts.DataSource =
                            productsTable.DefaultView;
                    }
                }

                if (dgvProducts.Columns.Contains("ProductId"))
                    dgvProducts.Columns["ProductId"].Visible =
                        false;

                if (dgvProducts.Columns.Contains("ProductName"))
                    dgvProducts.Columns["ProductName"]
                        .HeaderText = "Product Name";

                if (dgvProducts.Columns.Contains("Price"))
                {
                    dgvProducts.Columns["Price"].HeaderText =
                        "Selling Price";

                    dgvProducts.Columns["Price"]
                        .DefaultCellStyle.Format = "N2";
                }

                if (dgvProducts.Columns.Contains("StockQuantity"))
                    dgvProducts.Columns["StockQuantity"]
                        .HeaderText = "Available Stock";

                FilterProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to load products:\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =========================================
        // SEARCH PRODUCTS
        // =========================================
        private void txtSearch_TextChanged(
            object sender, EventArgs e)
        {
            FilterProducts();
        }

        private void FilterProducts()
        {
            if (productsTable == null)
                return;

            string search = txtSearch.Text.Trim()
                .Replace("[", "[[]")
                .Replace("]", "[]]")
                .Replace("%", "[%]")
                .Replace("*", "[*]")
                .Replace("'", "''");

            try
            {
                productsTable.DefaultView.RowFilter =
                    "ProductName LIKE '%" + search + "%'";
            }
            catch
            {
                productsTable.DefaultView.RowFilter = "";
            }
        }

        // =========================================
        // ADD TO CART
        // =========================================
        private void btnAddToCart_Click(
            object sender, EventArgs e)
        {
            DataRowView selected =
                dgvProducts.CurrentRow == null
                ? null
                : dgvProducts.CurrentRow.DataBoundItem
                    as DataRowView;

            if (selected == null)
            {
                MessageBox.Show(
                    "Please select a product.");
                return;
            }

            int productId =
                Convert.ToInt32(selected["ProductId"]);

            string productName =
                selected["ProductName"].ToString();

            decimal price =
                Convert.ToDecimal(selected["Price"]);

            int stock =
                Convert.ToInt32(selected["StockQuantity"]);

            int quantity =
                Convert.ToInt32(nudQuantity.Value);

            CartItem existing = cart.FirstOrDefault(
                x => x.ProductId == productId);

            int requested = quantity +
                (existing == null ? 0 : existing.Quantity);

            if (requested > stock)
            {
                MessageBox.Show(
                    "Insufficient stock!\nAvailable: " + stock,
                    "Stock Warning",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (existing != null)
            {
                existing.Quantity += quantity;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = productId,
                    ProductName = productName,
                    Quantity = quantity,
                    UnitPrice = price
                });
            }

            RefreshCart();
        }

        // =========================================
        // REMOVE ITEM
        // =========================================
        private void btnRemoveItem_Click(
            object sender, EventArgs e)
        {
            CartItem selected =
                dgvCart.CurrentRow == null
                ? null
                : dgvCart.CurrentRow.DataBoundItem as CartItem;

            if (selected == null)
            {
                MessageBox.Show(
                    "Please select an item to remove.");
                return;
            }

            cart.Remove(selected);
            RefreshCart();
        }

        // =========================================
        // CLEAR CART
        // =========================================
        private void btnClearCart_Click(
            object sender, EventArgs e)
        {
            if (cart.Count == 0)
                return;

            DialogResult result = MessageBox.Show(
                "Clear all items from the cart?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                cart.Clear();
                RefreshCart();
            }
        }

        // =========================================
        // REFRESH CART
        // =========================================
        private void RefreshCart()
        {
            dgvCart.DataSource = null;
            dgvCart.DataSource = cart.ToList();

            if (dgvCart.Columns.Contains("ProductId"))
                dgvCart.Columns["ProductId"].Visible = false;

            if (dgvCart.Columns.Contains("ProductName"))
                dgvCart.Columns["ProductName"].HeaderText =
                    "Product Name";

            if (dgvCart.Columns.Contains("UnitPrice"))
            {
                dgvCart.Columns["UnitPrice"].HeaderText =
                    "Unit Price";

                dgvCart.Columns["UnitPrice"]
                    .DefaultCellStyle.Format = "N2";
            }

            if (dgvCart.Columns.Contains("Subtotal"))
                dgvCart.Columns["Subtotal"]
                    .DefaultCellStyle.Format = "N2";

            UpdateTotals();
        }

        private decimal GetTotal()
        {
            return cart.Sum(x => x.Subtotal);
        }

        private void txtAmountPaid_TextChanged(
            object sender, EventArgs e)
        {
            UpdateTotals();
        }

        private void UpdateTotals()
        {
            decimal total = GetTotal();

            lblTotal.Text = "₱" + total.ToString("N2");

            decimal paid;

            if (decimal.TryParse(
                txtAmountPaid.Text,
                NumberStyles.Number,
                CultureInfo.CurrentCulture,
                out paid) && paid >= total)
            {
                lblChange.Text =
                    "₱" + (paid - total).ToString("N2");
            }
            else
            {
                lblChange.Text = "₱0.00";
            }
        }

        // =========================================
        // SQL DECIMAL HELPER
        // =========================================
        private static void AddDecimalParameter(
            SqlCommand cmd,
            string name,
            decimal value)
        {
            SqlParameter parameter =
                cmd.Parameters.Add(name, SqlDbType.Decimal);

            parameter.Precision = 18;
            parameter.Scale = 2;
            parameter.Value = value;
        }

        // =========================================
        // COMPLETE CHECKOUT
        // =========================================
        private void btnCheckout_Click(
            object sender, EventArgs e)
        {
            if (cart.Count == 0)
            {
                MessageBox.Show(
                    "Please add products to the cart.");
                return;
            }

            decimal amountPaid;

            if (!decimal.TryParse(
                txtAmountPaid.Text,
                NumberStyles.Number,
                CultureInfo.CurrentCulture,
                out amountPaid))
            {
                MessageBox.Show(
                    "Please enter a valid payment amount.");
                return;
            }

            decimal total = GetTotal();

            if (amountPaid < total)
            {
                MessageBox.Show(
                    "Insufficient payment.\nTotal: ₱" +
                    total.ToString("N2"));
                return;
            }

            if (amountPaid > 9999999999999999.99m)
            {
                MessageBox.Show(
                    "Payment amount is too large.");
                return;
            }

            DialogResult confirm = MessageBox.Show(
                "Complete this sale?\n\n" +
                "Total: ₱" + total.ToString("N2") +
                "\nAmount Paid: ₱" +
                amountPaid.ToString("N2") +
                "\nChange: ₱" +
                (amountPaid - total).ToString("N2"),
                "Confirm Checkout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes)
                return;

            btnCheckout.Enabled = false;

            int saleId = 0;
            decimal verifiedTotal = 0m;
            bool saleCommitted = false;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    using (SqlTransaction transaction =
                        con.BeginTransaction(
                            IsolationLevel.ReadCommitted))
                    {
                        try
                        {
                            // Verify current account
                            using (SqlCommand cmd =
                                new SqlCommand(@"
                                    SELECT COUNT(*)
                                    FROM dbo.Users u
                                    INNER JOIN dbo.Roles r
                                        ON u.RoleId = r.RoleId
                                    WHERE u.UserId = @UserId
                                      AND u.IsActive = 1
                                      AND r.RoleName IN
                                      ('Admin', 'Manager', 'Cashier')",
                                    con, transaction))
                            {
                                cmd.Parameters.Add(
                                    "@UserId", SqlDbType.Int)
                                    .Value = currentUserId;

                                if (Convert.ToInt32(
                                    cmd.ExecuteScalar()) != 1)
                                {
                                    throw new Exception(
                                        "Account is not authorized.");
                                }
                            }

                            // Recheck stock and prices
                            foreach (CartItem item in
                                cart.OrderBy(x => x.ProductId))
                            {
                                using (SqlCommand cmd =
                                    new SqlCommand(@"
                                        SELECT Price, StockQty
                                        FROM dbo.Products
                                            WITH (UPDLOCK, HOLDLOCK)
                                        WHERE ProductId = @ProductId
                                          AND IsActive = 1",
                                        con, transaction))
                                {
                                    cmd.Parameters.Add(
                                        "@ProductId", SqlDbType.Int)
                                        .Value = item.ProductId;

                                    using (SqlDataReader reader =
                                        cmd.ExecuteReader())
                                    {
                                        if (!reader.Read())
                                        {
                                            throw new Exception(
                                                "Product is no longer active: " +
                                                item.ProductName);
                                        }

                                        int stock =
                                            Convert.ToInt32(
                                                reader["StockQty"]);

                                        decimal dbPrice =
                                            Convert.ToDecimal(
                                                reader["Price"]);

                                        if (stock < item.Quantity)
                                        {
                                            throw new Exception(
                                                "Insufficient stock for " +
                                                item.ProductName);
                                        }

                                        if (dbPrice != item.UnitPrice)
                                        {
                                            throw new Exception(
                                                "Price changed for " +
                                                item.ProductName +
                                                ". Reload products and retry.");
                                        }

                                        verifiedTotal +=
                                            dbPrice * item.Quantity;
                                    }
                                }
                            }

                            if (amountPaid < verifiedTotal)
                            {
                                throw new Exception(
                                    "Payment is insufficient.");
                            }

                            decimal change =
                                amountPaid - verifiedTotal;

                            // Save sale
                            using (SqlCommand cmd =
                                new SqlCommand(@"
                                    INSERT INTO dbo.Sales
                                    (
                                        CashierId,
                                        TotalAmount,
                                        AmountPaid,
                                        ChangeAmount,
                                        PaymentMethod
                                    )
                                    OUTPUT INSERTED.SaleId
                                    VALUES
                                    (
                                        @CashierId,
                                        @Total,
                                        @Paid,
                                        @Change,
                                        'Cash'
                                    )",
                                    con, transaction))
                            {
                                cmd.Parameters.Add(
                                    "@CashierId", SqlDbType.Int)
                                    .Value = currentUserId;

                                AddDecimalParameter(
                                    cmd, "@Total", verifiedTotal);

                                AddDecimalParameter(
                                    cmd, "@Paid", amountPaid);

                                AddDecimalParameter(
                                    cmd, "@Change", change);

                                saleId = Convert.ToInt32(
                                    cmd.ExecuteScalar());
                            }

                            // Save purchased items
                            // and deduct inventory stock
                            foreach (CartItem item in
                                cart.OrderBy(x => x.ProductId))
                            {
                                using (SqlCommand cmd =
                                    new SqlCommand(@"
                                        UPDATE dbo.Products
                                        SET StockQty =
                                            StockQty - @Quantity
                                        WHERE ProductId = @ProductId
                                          AND IsActive = 1
                                          AND StockQty >= @Quantity",
                                        con, transaction))
                                {
                                    cmd.Parameters.Add(
                                        "@Quantity", SqlDbType.Int)
                                        .Value = item.Quantity;

                                    cmd.Parameters.Add(
                                        "@ProductId", SqlDbType.Int)
                                        .Value = item.ProductId;

                                    if (cmd.ExecuteNonQuery() != 1)
                                    {
                                        throw new Exception(
                                            "Unable to deduct stock for " +
                                            item.ProductName);
                                    }
                                }

                                using (SqlCommand cmd =
                                    new SqlCommand(@"
                                        INSERT INTO dbo.SaleItems
                                        (
                                            SaleId,
                                            ProductId,
                                            Quantity,
                                            UnitPrice
                                        )
                                        VALUES
                                        (
                                            @SaleId,
                                            @ProductId,
                                            @Quantity,
                                            @UnitPrice
                                        )",
                                        con, transaction))
                                {
                                    cmd.Parameters.Add(
                                        "@SaleId", SqlDbType.Int)
                                        .Value = saleId;

                                    cmd.Parameters.Add(
                                        "@ProductId", SqlDbType.Int)
                                        .Value = item.ProductId;

                                    cmd.Parameters.Add(
                                        "@Quantity", SqlDbType.Int)
                                        .Value = item.Quantity;

                                    AddDecimalParameter(
                                        cmd, "@UnitPrice",
                                        item.UnitPrice);

                                    cmd.ExecuteNonQuery();
                                }
                            }

                            transaction.Commit();
                            saleCommitted = true;
                        }
                        catch
                        {
                            if (!saleCommitted)
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch
                                {
                                    // Transaction may already be closed.
                                }
                            }

                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Checkout failed:\n" + ex.Message,
                    "Checkout Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                LoadProducts();
                btnCheckout.Enabled = true;
                return;
            }

            // =========================================
            // SALE SUCCESSFUL - DATABASE COMMITTED
            // =========================================
            try
            {
                MessageBox.Show(
                    "Sale completed successfully!" +
                    "\nSale ID: " + saleId +
                    "\nTotal: ₱" +
                    verifiedTotal.ToString("N2") +
                    "\nChange: ₱" +
                    (amountPaid - verifiedTotal).ToString("N2"),
                    "Sale Complete",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                cart.Clear();
                txtAmountPaid.Clear();
                nudQuantity.Value = 1;

                RefreshCart();
                LoadProducts();

                // =====================================
                // NEW: RECEIPT GENERATION
                // =====================================
                DialogResult printResult =
                    MessageBox.Show(
                        "Transaction saved successfully!\n\n" +
                        "Sale ID: " + saleId +
                        "\n\nWould you like to print the receipt?",
                        "RenOrPOS - Receipt",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (printResult == DialogResult.Yes)
                {
                    try
                    {
                        ReceiptService receipt =
                            new ReceiptService();

                        receipt.PrintReceipt(saleId);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Sale was saved successfully, " +
                            "but the receipt could not be opened:\n" +
                            ex.Message,
                            "Receipt Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }
            finally
            {
                btnCheckout.Enabled = true;
            }
        }

        // =========================================
        // CLOSE POS
        // =========================================
        private void btnClose_Click(
            object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
