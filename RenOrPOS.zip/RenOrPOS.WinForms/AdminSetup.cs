﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using RenOrPOS.Data;
using System.Data;

namespace RenOrPOS.WinForms
{
    public static class AdminSetup
    {
        public static void CreateAdmin()
        {
            string connectionString =
                @"Data Source=.\SQLEXPRESS;Initial Catalog=ortega;Integrated Security=True;TrustServerCertificate=True;";

            string username = "admin";
            string password = "Admin@12345";

            string hash, salt;

            PasswordHasher.HashPassword(
                password, out hash, out salt);

            using (SqlConnection con =
                new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"
                    IF NOT EXISTS
                    (
                        SELECT 1 FROM dbo.Users
                        WHERE Username = @Username
                    )
                    BEGIN
                        INSERT INTO dbo.Users
                        (Username, PasswordHash, Salt, FullName, RoleId, IsActive)
                        SELECT
                            @Username, @PasswordHash, @Salt,
                            @FullName, RoleId, 1
                        FROM dbo.Roles
                        WHERE RoleName = 'Admin'
                    END";

                using (SqlCommand cmd =
                    new SqlCommand(query, con))
                {
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 50)
                        .Value = username;
                    cmd.Parameters.Add("@PasswordHash", SqlDbType.VarChar, 256)
                        .Value = hash;
                    cmd.Parameters.Add("@Salt", SqlDbType.VarChar, 128)
                        .Value = salt;
                    cmd.Parameters.Add("@FullName", SqlDbType.NVarChar, 100)
                        .Value = "System Administrator";

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
