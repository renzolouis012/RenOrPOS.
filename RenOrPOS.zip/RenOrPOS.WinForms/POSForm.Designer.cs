﻿
namespace RenOrPOS.WinForms
{
    partial class POSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Panel pnlProducts;
        private System.Windows.Forms.Panel pnlCart;
        private System.Windows.Forms.Panel pnlCheckout;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblProductsTitle;
        private System.Windows.Forms.Label lblCartTitle;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Label lblPaidCaption;
        private System.Windows.Forms.Label lblChangeCaption;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblChange;

        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtAmountPaid;

        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.DataGridView dgvCart;

        private System.Windows.Forms.NumericUpDown nudQuantity;

        private System.Windows.Forms.Button btnAddToCart;
        private System.Windows.Forms.Button btnRemoveItem;
        private System.Windows.Forms.Button btnClearCart;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Button btnClose;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">
        /// true if managed resources should be disposed;
        /// otherwise, false.
        /// </param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.pnlHeader =
                new System.Windows.Forms.Panel();

            this.pnlProducts =
                new System.Windows.Forms.Panel();

            this.pnlCart =
                new System.Windows.Forms.Panel();

            this.pnlCheckout =
                new System.Windows.Forms.Panel();

            this.lblTitle =
                new System.Windows.Forms.Label();

            this.lblProductsTitle =
                new System.Windows.Forms.Label();

            this.lblCartTitle =
                new System.Windows.Forms.Label();

            this.lblQuantity =
                new System.Windows.Forms.Label();

            this.lblTotalCaption =
                new System.Windows.Forms.Label();

            this.lblPaidCaption =
                new System.Windows.Forms.Label();

            this.lblChangeCaption =
                new System.Windows.Forms.Label();

            this.lblTotal =
                new System.Windows.Forms.Label();

            this.lblChange =
                new System.Windows.Forms.Label();

            this.txtSearch =
                new System.Windows.Forms.TextBox();

            this.txtAmountPaid =
                new System.Windows.Forms.TextBox();

            this.dgvProducts =
                new System.Windows.Forms.DataGridView();

            this.dgvCart =
                new System.Windows.Forms.DataGridView();

            this.nudQuantity =
                new System.Windows.Forms.NumericUpDown();

            this.btnAddToCart =
                new System.Windows.Forms.Button();

            this.btnRemoveItem =
                new System.Windows.Forms.Button();

            this.btnClearCart =
                new System.Windows.Forms.Button();

            this.btnCheckout =
                new System.Windows.Forms.Button();

            this.btnClose =
                new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvProducts)).BeginInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvCart)).BeginInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.nudQuantity)).BeginInit();

            this.pnlHeader.SuspendLayout();
            this.pnlProducts.SuspendLayout();
            this.pnlCart.SuspendLayout();
            this.pnlCheckout.SuspendLayout();

            this.SuspendLayout();

            //
            // pnlHeader
            //
            this.pnlHeader.BackColor =
                System.Drawing.Color.FromArgb(41, 54, 93);

            this.pnlHeader.Dock =
                System.Windows.Forms.DockStyle.Top;

            this.pnlHeader.Height = 80;

            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.btnClose);

            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;

            this.lblTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    20F,
                    System.Drawing.FontStyle.Bold);

            this.lblTitle.ForeColor =
                System.Drawing.Color.White;

            this.lblTitle.Location =
                new System.Drawing.Point(25, 19);

            this.lblTitle.Name = "lblTitle";

            this.lblTitle.Text =
                "RenOrPOS | Point of Sale";

            //
            // btnClose
            //
            this.btnClose.BackColor =
                System.Drawing.Color.FromArgb(
                    222, 230, 246);

            this.btnClose.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnClose.Location =
                new System.Drawing.Point(1050, 22);

            this.btnClose.Name = "btnClose";

            this.btnClose.Size =
                new System.Drawing.Size(95, 36);

            this.btnClose.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnClose.Text = "Close";

            this.btnClose.UseVisualStyleBackColor = false;

            this.btnClose.Click +=
                new System.EventHandler(
                    this.btnClose_Click);

            //
            // pnlProducts
            //
            this.pnlProducts.BackColor =
                System.Drawing.Color.White;

            this.pnlProducts.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.pnlProducts.Location =
                new System.Drawing.Point(20, 100);

            this.pnlProducts.Name = "pnlProducts";

            this.pnlProducts.Size =
                new System.Drawing.Size(550, 580);

            this.pnlProducts.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left;

            this.pnlProducts.Controls.Add(
                this.lblProductsTitle);

            this.pnlProducts.Controls.Add(
                this.txtSearch);

            this.pnlProducts.Controls.Add(
                this.dgvProducts);

            this.pnlProducts.Controls.Add(
                this.lblQuantity);

            this.pnlProducts.Controls.Add(
                this.nudQuantity);

            this.pnlProducts.Controls.Add(
                this.btnAddToCart);

            //
            // lblProductsTitle
            //
            this.lblProductsTitle.AutoSize = true;

            this.lblProductsTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    15F,
                    System.Drawing.FontStyle.Bold);

            this.lblProductsTitle.Location =
                new System.Drawing.Point(18, 15);

            this.lblProductsTitle.Name =
                "lblProductsTitle";

            this.lblProductsTitle.Text =
                "Available Products";

            //
            // txtSearch
            //
            this.txtSearch.Location =
                new System.Drawing.Point(20, 65);

            this.txtSearch.Name = "txtSearch";

            this.txtSearch.Size =
                new System.Drawing.Size(505, 30);

            this.txtSearch.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            //
            // dgvProducts
            //
            this.dgvProducts.Location =
                new System.Drawing.Point(20, 110);

            this.dgvProducts.Name = "dgvProducts";

            this.dgvProducts.Size =
                new System.Drawing.Size(505, 360);

            this.dgvProducts.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvProducts.BackgroundColor =
                System.Drawing.Color.White;

            this.dgvProducts.ReadOnly = true;

            this.dgvProducts.AllowUserToAddRows = false;

            this.dgvProducts.AllowUserToDeleteRows = false;

            this.dgvProducts.MultiSelect = false;

            this.dgvProducts.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode
                    .FullRowSelect;

            this.dgvProducts.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode
                    .Fill;

            //
            // lblQuantity
            //
            this.lblQuantity.AutoSize = true;

            this.lblQuantity.Location =
                new System.Drawing.Point(20, 505);

            this.lblQuantity.Name = "lblQuantity";

            this.lblQuantity.Text = "Quantity:";

            this.lblQuantity.Anchor =
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left;

            //
            // nudQuantity
            //
            this.nudQuantity.Location =
                new System.Drawing.Point(110, 500);

            this.nudQuantity.Name = "nudQuantity";

            this.nudQuantity.Size =
                new System.Drawing.Size(100, 30);

            this.nudQuantity.Minimum = 1;

            this.nudQuantity.Maximum = 100000;

            this.nudQuantity.Value = 1;

            this.nudQuantity.Anchor =
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Left;

            //
            // btnAddToCart
            //
            this.btnAddToCart.BackColor =
                System.Drawing.Color.FromArgb(
                    85, 105, 190);

            this.btnAddToCart.ForeColor =
                System.Drawing.Color.White;

            this.btnAddToCart.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnAddToCart.Location =
                new System.Drawing.Point(365, 495);

            this.btnAddToCart.Name = "btnAddToCart";

            this.btnAddToCart.Size =
                new System.Drawing.Size(160, 42);

            this.btnAddToCart.Anchor =
                System.Windows.Forms.AnchorStyles.Bottom |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnAddToCart.Text = "Add to Cart";

            this.btnAddToCart.UseVisualStyleBackColor = false;

            this.btnAddToCart.Click +=
                new System.EventHandler(
                    this.btnAddToCart_Click);

            //
            // pnlCart
            //
            this.pnlCart.BackColor =
                System.Drawing.Color.White;

            this.pnlCart.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.pnlCart.Location =
                new System.Drawing.Point(590, 100);

            this.pnlCart.Name = "pnlCart";

            this.pnlCart.Size =
                new System.Drawing.Size(570, 350);

            this.pnlCart.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.pnlCart.Controls.Add(
                this.lblCartTitle);

            this.pnlCart.Controls.Add(
                this.dgvCart);

            this.pnlCart.Controls.Add(
                this.btnRemoveItem);

            this.pnlCart.Controls.Add(
                this.btnClearCart);

            //
            // lblCartTitle
            //
            this.lblCartTitle.AutoSize = true;

            this.lblCartTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    15F,
                    System.Drawing.FontStyle.Bold);

            this.lblCartTitle.Location =
                new System.Drawing.Point(18, 15);

            this.lblCartTitle.Name = "lblCartTitle";

            this.lblCartTitle.Text = "Shopping Cart";

            //
            // dgvCart
            //
            this.dgvCart.Location =
                new System.Drawing.Point(20, 60);

            this.dgvCart.Name = "dgvCart";

            this.dgvCart.Size =
                new System.Drawing.Size(530, 210);

            this.dgvCart.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right;

            this.dgvCart.BackgroundColor =
                System.Drawing.Color.White;

            this.dgvCart.ReadOnly = true;

            this.dgvCart.AllowUserToAddRows = false;

            this.dgvCart.AllowUserToDeleteRows = false;

            this.dgvCart.MultiSelect = false;

            this.dgvCart.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode
                    .FullRowSelect;

            this.dgvCart.AutoSizeColumnsMode =
                System.Windows.Forms.DataGridViewAutoSizeColumnsMode
                    .Fill;

            //
            // btnRemoveItem
            //
            this.btnRemoveItem.BackColor =
                System.Drawing.Color.FromArgb(
                    240, 207, 207);

            this.btnRemoveItem.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnRemoveItem.Location =
                new System.Drawing.Point(20, 290);

            this.btnRemoveItem.Name = "btnRemoveItem";

            this.btnRemoveItem.Size =
                new System.Drawing.Size(160, 40);

            this.btnRemoveItem.Text = "Remove Selected";

            this.btnRemoveItem.UseVisualStyleBackColor =
                false;

            this.btnRemoveItem.Click +=
                new System.EventHandler(
                    this.btnRemoveItem_Click);

            //
            // btnClearCart
            //
            this.btnClearCart.BackColor =
                System.Drawing.Color.FromArgb(
                    227, 231, 239);

            this.btnClearCart.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnClearCart.Location =
                new System.Drawing.Point(195, 290);

            this.btnClearCart.Name = "btnClearCart";

            this.btnClearCart.Size =
                new System.Drawing.Size(125, 40);

            this.btnClearCart.Text = "Clear Cart";

            this.btnClearCart.UseVisualStyleBackColor =
                false;

            this.btnClearCart.Click +=
                new System.EventHandler(
                    this.btnClearCart_Click);

            //
            // pnlCheckout
            //
            this.pnlCheckout.BackColor =
                System.Drawing.Color.White;

            this.pnlCheckout.BorderStyle =
                System.Windows.Forms.BorderStyle.FixedSingle;

            this.pnlCheckout.Location =
                new System.Drawing.Point(590, 470);

            this.pnlCheckout.Name = "pnlCheckout";

            this.pnlCheckout.Size =
                new System.Drawing.Size(570, 210);

            this.pnlCheckout.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left |
                System.Windows.Forms.AnchorStyles.Right |
                System.Windows.Forms.AnchorStyles.Bottom;

            this.pnlCheckout.Controls.Add(
                this.lblTotalCaption);

            this.pnlCheckout.Controls.Add(
                this.lblTotal);

            this.pnlCheckout.Controls.Add(
                this.lblPaidCaption);

            this.pnlCheckout.Controls.Add(
                this.txtAmountPaid);

            this.pnlCheckout.Controls.Add(
                this.lblChangeCaption);

            this.pnlCheckout.Controls.Add(
                this.lblChange);

            this.pnlCheckout.Controls.Add(
                this.btnCheckout);

            //
            // lblTotalCaption
            //
            this.lblTotalCaption.AutoSize = true;

            this.lblTotalCaption.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    13F,
                    System.Drawing.FontStyle.Bold);

            this.lblTotalCaption.Location =
                new System.Drawing.Point(20, 20);

            this.lblTotalCaption.Name =
                "lblTotalCaption";

            this.lblTotalCaption.Text = "TOTAL:";

            //
            // lblTotal
            //
            this.lblTotal.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    18F,
                    System.Drawing.FontStyle.Bold);

            this.lblTotal.ForeColor =
                System.Drawing.Color.FromArgb(
                    40, 115, 88);

            this.lblTotal.Location =
                new System.Drawing.Point(310, 15);

            this.lblTotal.Name = "lblTotal";

            this.lblTotal.Size =
                new System.Drawing.Size(230, 40);

            this.lblTotal.Text = "₱0.00";

            this.lblTotal.TextAlign =
                System.Drawing.ContentAlignment.MiddleRight;

            this.lblTotal.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            //
            // lblPaidCaption
            //
            this.lblPaidCaption.AutoSize = true;

            this.lblPaidCaption.Location =
                new System.Drawing.Point(20, 75);

            this.lblPaidCaption.Name =
                "lblPaidCaption";

            this.lblPaidCaption.Text = "Amount Paid:";

            //
            // txtAmountPaid
            //
            this.txtAmountPaid.Location =
                new System.Drawing.Point(310, 70);

            this.txtAmountPaid.Name = "txtAmountPaid";

            this.txtAmountPaid.Size =
                new System.Drawing.Size(230, 30);

            this.txtAmountPaid.TextAlign =
                System.Windows.Forms.HorizontalAlignment.Right;

            this.txtAmountPaid.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            //
            // lblChangeCaption
            //
            this.lblChangeCaption.AutoSize = true;

            this.lblChangeCaption.Location =
                new System.Drawing.Point(20, 120);

            this.lblChangeCaption.Name =
                "lblChangeCaption";

            this.lblChangeCaption.Text = "Change:";

            //
            // lblChange
            //
            this.lblChange.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    13F,
                    System.Drawing.FontStyle.Bold);

            this.lblChange.Location =
                new System.Drawing.Point(310, 110);

            this.lblChange.Name = "lblChange";

            this.lblChange.Size =
                new System.Drawing.Size(230, 35);

            this.lblChange.Text = "₱0.00";

            this.lblChange.TextAlign =
                System.Drawing.ContentAlignment.MiddleRight;

            this.lblChange.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            //
            // btnCheckout
            //
            this.btnCheckout.BackColor =
                System.Drawing.Color.FromArgb(
                    36, 150, 100);

            this.btnCheckout.ForeColor =
                System.Drawing.Color.White;

            this.btnCheckout.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            this.btnCheckout.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.btnCheckout.Location =
                new System.Drawing.Point(310, 155);

            this.btnCheckout.Name = "btnCheckout";

            this.btnCheckout.Size =
                new System.Drawing.Size(230, 42);

            this.btnCheckout.Text = "COMPLETE SALE";

            this.btnCheckout.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Right;

            this.btnCheckout.UseVisualStyleBackColor =
                false;

            this.btnCheckout.Click +=
                new System.EventHandler(
                    this.btnCheckout_Click);

            //
            // POSForm
            //
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(8F, 16F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.BackColor =
                System.Drawing.Color.FromArgb(
                    245, 247, 252);

            this.ClientSize =
                new System.Drawing.Size(1180, 710);

            this.MinimumSize =
                new System.Drawing.Size(1000, 650);

            this.Font =
                new System.Drawing.Font("Segoe UI", 10F);

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.Name = "POSForm";

            this.Text =
                "RenOrPOS | Point of Sale";

            this.Controls.Add(this.pnlProducts);
            this.Controls.Add(this.pnlCart);
            this.Controls.Add(this.pnlCheckout);
            this.Controls.Add(this.pnlHeader);

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvProducts)).EndInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvCart)).EndInit();

            ((System.ComponentModel.ISupportInitialize)
                (this.nudQuantity)).EndInit();

            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();

            this.pnlProducts.ResumeLayout(false);
            this.pnlProducts.PerformLayout();

            this.pnlCart.ResumeLayout(false);
            this.pnlCart.PerformLayout();

            this.pnlCheckout.ResumeLayout(false);
            this.pnlCheckout.PerformLayout();

            this.ResumeLayout(false);
        }

        #endregion
    }
}
