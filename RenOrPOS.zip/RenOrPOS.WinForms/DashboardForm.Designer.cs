﻿
namespace RenOrPOS.WinForms
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlContent;

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Label lblHeaderTitle;
        private System.Windows.Forms.Label label1;

        private System.Windows.Forms.Label lblTotalProducts;
        private System.Windows.Forms.Label lblLowStock;
        private System.Windows.Forms.Label lblCategories;
        private System.Windows.Forms.Label lblActiveUsers;

        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Button btnUserManagement;
        private System.Windows.Forms.Button btnPOS;
        private System.Windows.Forms.Button btnSalesHistory;
        private System.Windows.Forms.Button btnSalesReports;
        private System.Windows.Forms.Button btnLogout;

        private System.Windows.Forms.Panel pnlCardProducts;
        private System.Windows.Forms.Panel pnlCardLowStock;
        private System.Windows.Forms.Panel pnlCardCategories;
        private System.Windows.Forms.Panel pnlCardUsers;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components =
                new System.ComponentModel.Container();

            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlContent = new System.Windows.Forms.Panel();

            this.lblLogo = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.lblHeaderTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();

            this.lblTotalProducts = new System.Windows.Forms.Label();
            this.lblLowStock = new System.Windows.Forms.Label();
            this.lblCategories = new System.Windows.Forms.Label();
            this.lblActiveUsers = new System.Windows.Forms.Label();

            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnInventory = new System.Windows.Forms.Button();
            this.btnUserManagement = new System.Windows.Forms.Button();
            this.btnPOS = new System.Windows.Forms.Button();
            this.btnSalesHistory = new System.Windows.Forms.Button();
            this.btnSalesReports = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();

            this.pnlCardProducts = new System.Windows.Forms.Panel();
            this.pnlCardLowStock = new System.Windows.Forms.Panel();
            this.pnlCardCategories = new System.Windows.Forms.Panel();
            this.pnlCardUsers = new System.Windows.Forms.Panel();

            this.SuspendLayout();

            // =====================================
            // FORM
            // =====================================
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(6F, 13F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(1220, 800);

            this.MinimumSize =
                new System.Drawing.Size(950, 650);

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.BackColor =
                System.Drawing.Color.FromArgb(245, 247, 252);

            this.Font =
                new System.Drawing.Font("Segoe UI", 10F);

            this.Name = "DashboardForm";
            this.Text = "RenOrPOS - Dashboard";

            // =====================================
            // SIDEBAR
            // =====================================
            this.pnlSidebar.Dock =
                System.Windows.Forms.DockStyle.Left;

            this.pnlSidebar.Width = 280;

            this.pnlSidebar.BackColor =
                System.Drawing.Color.FromArgb(25, 47, 70);

            this.pnlSidebar.AutoScroll = true;

            // LOGO
            this.lblLogo.Text = "RenOrPOS";

            this.lblLogo.Font =
                new System.Drawing.Font(
                    "Segoe UI", 24F,
                    System.Drawing.FontStyle.Bold);

            this.lblLogo.ForeColor =
                System.Drawing.Color.White;

            this.lblLogo.AutoSize = true;

            this.lblLogo.Location =
                new System.Drawing.Point(20, 35);

            this.lblSubtitle.Text = "Management System";

            this.lblSubtitle.ForeColor =
                System.Drawing.Color.LightGray;

            this.lblSubtitle.AutoSize = true;

            this.lblSubtitle.Location =
                new System.Drawing.Point(25, 90);

            this.pnlSidebar.Controls.Add(this.lblLogo);
            this.pnlSidebar.Controls.Add(this.lblSubtitle);

            // =====================================
            // NAVIGATION BUTTONS
            // =====================================
            ConfigureNavButton(
                this.btnDashboard,
                "Dashboard",
                190,
                this.btnDashboard_Click);

            ConfigureNavButton(
                this.btnInventory,
                "Inventory",
                245,
                this.btnInventory_Click);

            ConfigureNavButton(
                this.btnUserManagement,
                "User Management",
                300,
                this.btnUserManagement_Click);

            ConfigureNavButton(
                this.btnPOS,
                "Point of Sale",
                355,
                this.btnPOS_Click);

            ConfigureNavButton(
                this.btnSalesHistory,
                "Sales History",
                410,
                this.btnSalesHistory_Click);

            ConfigureNavButton(
                this.btnSalesReports,
                "Sales Reports",
                465,
                this.btnSalesReports_Click);

            ConfigureNavButton(
                this.btnLogout,
                "Logout",
                535,
                this.btnLogout_Click);

            // =====================================
            // TOP HEADER
            // =====================================
            this.pnlTop.Dock =
                System.Windows.Forms.DockStyle.Top;

            this.pnlTop.Height = 130;

            this.pnlTop.BackColor =
                System.Drawing.Color.FromArgb(115, 130, 145);

            // =====================================
            // CONTENT PANEL
            // =====================================
            this.pnlContent.Dock =
                System.Windows.Forms.DockStyle.Fill;

            this.pnlContent.BackColor =
                System.Drawing.Color.FromArgb(245, 247, 252);

            // DASHBOARD TITLE
            this.lblHeaderTitle.Text = "Dashboard";

            this.lblHeaderTitle.Font =
                new System.Drawing.Font(
                    "Segoe UI", 23F,
                    System.Drawing.FontStyle.Bold);

            this.lblHeaderTitle.AutoSize = true;

            this.lblHeaderTitle.Location =
                new System.Drawing.Point(35, 20);

            this.label1.Text =
                "Welcome to RenOrPOS Inventory Management System";

            this.label1.Font =
                new System.Drawing.Font("Segoe UI", 10F);

            this.label1.AutoSize = true;

            this.label1.Location =
                new System.Drawing.Point(40, 70);

            this.pnlContent.Controls.Add(this.lblHeaderTitle);
            this.pnlContent.Controls.Add(this.label1);

            // =====================================
            // DASHBOARD CARDS
            // =====================================
            ConfigureMetricCard(
                this.pnlCardProducts,
                this.lblTotalProducts,
                "Total Products",
                35, 125,
                System.Drawing.Color.FromArgb(232, 240, 255));

            ConfigureMetricCard(
                this.pnlCardLowStock,
                this.lblLowStock,
                "Low Stock",
                465, 125,
                System.Drawing.Color.FromArgb(255, 244, 230));

            ConfigureMetricCard(
                this.pnlCardCategories,
                this.lblCategories,
                "Categories",
                35, 340,
                System.Drawing.Color.FromArgb(233, 249, 239));

            ConfigureMetricCard(
                this.pnlCardUsers,
                this.lblActiveUsers,
                "Active Users",
                465, 340,
                System.Drawing.Color.FromArgb(243, 237, 255));

            // =====================================
            // ADD PANELS
            // =====================================
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlSidebar);

            this.ResumeLayout(false);
        }

        // =====================================
        // NAVIGATION BUTTON HELPER
        // =====================================
        private void ConfigureNavButton(
            System.Windows.Forms.Button button,
            string text,
            int y,
            System.EventHandler clickHandler)
        {
            button.Text = text;
            button.Name = "btn" + text.Replace(" ", "");

            button.Font =
                new System.Drawing.Font(
                    "Segoe UI", 11F,
                    System.Drawing.FontStyle.Bold);

            button.Location =
                new System.Drawing.Point(25, y);

            button.Size =
                new System.Drawing.Size(230, 45);

            button.BackColor =
                System.Drawing.Color.White;

            button.ForeColor =
                System.Drawing.Color.Black;

            button.FlatStyle =
                System.Windows.Forms.FlatStyle.Flat;

            button.FlatAppearance.BorderSize = 0;

            button.Cursor =
                System.Windows.Forms.Cursors.Hand;

            button.Click += clickHandler;

            this.pnlSidebar.Controls.Add(button);
        }

        // =====================================
        // METRIC CARD HELPER
        // =====================================
        private void ConfigureMetricCard(
            System.Windows.Forms.Panel panel,
            System.Windows.Forms.Label valueLabel,
            string caption,
            int x,
            int y,
            System.Drawing.Color color)
        {
            panel.Location =
                new System.Drawing.Point(x, y);

            panel.Size =
                new System.Drawing.Size(400, 170);

            panel.BackColor = color;

            panel.Anchor =
                System.Windows.Forms.AnchorStyles.Top |
                System.Windows.Forms.AnchorStyles.Left;

            System.Windows.Forms.Label title =
                new System.Windows.Forms.Label();

            title.Text = caption;

            title.Font =
                new System.Drawing.Font(
                    "Segoe UI", 13F);

            title.AutoSize = true;

            title.Location =
                new System.Drawing.Point(25, 20);

            valueLabel.Text = "0";

            valueLabel.Font =
                new System.Drawing.Font(
                    "Segoe UI", 27F,
                    System.Drawing.FontStyle.Bold);

            valueLabel.AutoSize = true;

            valueLabel.Location =
                new System.Drawing.Point(30, 75);

            panel.Controls.Add(title);
            panel.Controls.Add(valueLabel);

            this.pnlContent.Controls.Add(panel);
        }

        #endregion
    }
}
