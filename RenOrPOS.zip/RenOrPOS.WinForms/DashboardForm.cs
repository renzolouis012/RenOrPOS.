﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class DashboardForm : Form
    {
        private readonly string currentRole;
        private readonly int currentUserId;

        public DashboardForm(string role, int userId)
        {
            if (userId <= 0)
                throw new ArgumentException(
                    "Invalid authenticated user ID.");

            bool allowed =
                string.Equals(role, "Admin",
                    StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Manager",
                    StringComparison.OrdinalIgnoreCase);

            if (!allowed)
                throw new UnauthorizedAccessException(
                    "Only Admin and Manager can open Dashboard.");

            currentRole = role;
            currentUserId = userId;

            InitializeComponent();
            ApplyRolePermissions();
            LoadDashboardMetrics();
        }

        // =========================================
        // ROLE PERMISSIONS
        // =========================================
        private void ApplyRolePermissions()
        {
            bool isAdmin = string.Equals(
                currentRole, "Admin",
                StringComparison.OrdinalIgnoreCase);

            bool isManager = string.Equals(
                currentRole, "Manager",
                StringComparison.OrdinalIgnoreCase);

            btnDashboard.Visible = isAdmin || isManager;
            btnInventory.Visible = isAdmin || isManager;
            btnUserManagement.Visible = isAdmin;
            btnPOS.Visible = isAdmin || isManager;
            btnSalesHistory.Visible = isAdmin || isManager;
            btnSalesReports.Visible = isAdmin || isManager;

            lblHeaderTitle.Text = "Dashboard";

            label1.Text =
                "Welcome to RenOrPOS Inventory Management System";
        }

        // =========================================
        // LOAD DASHBOARD METRICS
        // =========================================
        private void LoadDashboardMetrics()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    using (SqlCommand cmd =
                        new SqlCommand(
                            "dbo.usp_Dashboard_Metrics", con))
                    {
                        cmd.CommandType =
                            CommandType.StoredProcedure;

                        using (SqlDataReader reader =
                            cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lblTotalProducts.Text =
                                    Convert.ToString(
                                        reader["TotalProducts"]);

                                lblLowStock.Text =
                                    Convert.ToString(
                                        reader["LowStock"]);

                                lblCategories.Text =
                                    Convert.ToString(
                                        reader["TotalCategories"]);

                                lblActiveUsers.Text =
                                    Convert.ToString(
                                        reader["ActiveUsers"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to load dashboard metrics:\n" +
                    ex.Message,
                    "Dashboard Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =========================================
        // DASHBOARD BUTTON
        // =========================================
        private void btnDashboard_Click(
            object sender, EventArgs e)
        {
            lblHeaderTitle.Text = "Dashboard";
            LoadDashboardMetrics();
        }

        // =========================================
        // INVENTORY BUTTON
        // =========================================
        private void btnInventory_Click(
            object sender, EventArgs e)
        {
            try
            {
                using (InventoryForm inventory =
                    new InventoryForm())
                {
                    inventory.ShowDialog(this);
                }

                LoadDashboardMetrics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Inventory error:\n" + ex.Message);
            }
        }

        // =========================================
        // USER MANAGEMENT BUTTON
        // =========================================
        private void btnUserManagement_Click(
            object sender, EventArgs e)
        {
            if (!string.Equals(
                currentRole, "Admin",
                StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    "Access denied. Admin only.");
                return;
            }

            try
            {
                using (UserManagementForm users =
                    new UserManagementForm())
                {
                    users.ShowDialog(this);
                }

                LoadDashboardMetrics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "User Management error:\n" +
                    ex.Message);
            }
        }

        // =========================================
        // POINT OF SALE BUTTON
        // =========================================
        private void btnPOS_Click(
            object sender, EventArgs e)
        {
            try
            {
                using (POSForm pos =
                    new POSForm(currentUserId))
                {
                    pos.ShowDialog(this);
                }

                LoadDashboardMetrics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "POS error:\n" + ex.Message);
            }
        }

        // =========================================
        // SALES HISTORY BUTTON
        // =========================================
        private void btnSalesHistory_Click(
            object sender, EventArgs e)
        {
            try
            {
                using (SalesHistoryForm history =
                    new SalesHistoryForm(currentRole))
                {
                    history.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Sales History error:\n" +
                    ex.Message);
            }
        }

        // =========================================
        // SALES REPORTS BUTTON
        // =========================================
        private void btnSalesReports_Click(
            object sender, EventArgs e)
        {
            try
            {
                using (SalesReportsForm reports =
                    new SalesReportsForm(currentRole))
                {
                    reports.ShowDialog(this);
                }

                LoadDashboardMetrics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Sales Reports error:\n" +
                    ex.Message);
            }
        }

        // =========================================
        // LOGOUT BUTTON
        // =========================================
        private void btnLogout_Click(
            object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                this.Close();
        }
    }
}
