﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public class ReceiptService
    {
        private DataTable items;
        private int saleId;
        private string cashier;
        private string paymentMethod;
        private DateTime saleDate;
        private decimal total;
        private decimal paid;
        private decimal change;

        public void PrintReceipt(int selectedSaleId)
        {
            if (selectedSaleId <= 0)
                throw new ArgumentException("Invalid sale ID.");

            LoadReceipt(selectedSaleId);

            using (PrintDocument document = new PrintDocument())
            {
                document.DocumentName =
                    "RenOrPOS Receipt #" + saleId;

                int paperHeight = Math.Max(
                    650, 380 + items.Rows.Count * 110);

                document.DefaultPageSettings.PaperSize =
                    new PaperSize("80mm Receipt", 315, paperHeight);

                document.DefaultPageSettings.Margins =
                    new Margins(12, 12, 12, 12);

                document.PrintPage += Document_PrintPage;

                using (PrintPreviewDialog preview =
                    new PrintPreviewDialog())
                {
                    preview.Document = document;
                    preview.Width = 850;
                    preview.Height = 720;
                    preview.StartPosition =
                        FormStartPosition.CenterScreen;

                    preview.ShowDialog();
                }
            }
        }

        private void LoadReceipt(int selectedSaleId)
        {
            using (SqlConnection con = Db.GetConnection())
            {
                con.Open();

                string saleQuery = @"
                    SELECT
                        s.SaleId,
                        s.SaleDate,
                        s.TotalAmount,
                        s.AmountPaid,
                        s.ChangeAmount,
                        s.PaymentMethod,
                        u.Username AS Cashier
                    FROM dbo.Sales s
                    INNER JOIN dbo.Users u
                        ON s.CashierId = u.UserId
                    WHERE s.SaleId = @SaleId";

                using (SqlCommand cmd =
                    new SqlCommand(saleQuery, con))
                {
                    cmd.Parameters.Add(
                        "@SaleId", SqlDbType.Int)
                        .Value = selectedSaleId;

                    using (SqlDataReader reader =
                        cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                            throw new InvalidOperationException(
                                "Sale not found.");

                        saleId = Convert.ToInt32(
                            reader["SaleId"]);

                        saleDate = Convert.ToDateTime(
                            reader["SaleDate"]);

                        cashier = Convert.ToString(
                            reader["Cashier"]);

                        paymentMethod = Convert.ToString(
                            reader["PaymentMethod"]);

                        total = Convert.ToDecimal(
                            reader["TotalAmount"]);

                        paid = Convert.ToDecimal(
                            reader["AmountPaid"]);

                        change = Convert.ToDecimal(
                            reader["ChangeAmount"]);
                    }
                }

                string itemsQuery = @"
                    SELECT
                        p.Name AS ProductName,
                        si.Quantity,
                        si.UnitPrice,
                        si.Subtotal
                    FROM dbo.SaleItems si
                    INNER JOIN dbo.Products p
                        ON si.ProductId = p.ProductId
                    WHERE si.SaleId = @SaleId
                    ORDER BY si.SaleItemId";

                using (SqlCommand cmd =
                    new SqlCommand(itemsQuery, con))
                {
                    cmd.Parameters.Add(
                        "@SaleId", SqlDbType.Int)
                        .Value = selectedSaleId;

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(cmd))
                    {
                        items = new DataTable();
                        adapter.Fill(items);
                    }
                }
            }
        }

        private void Document_PrintPage(
            object sender,
            PrintPageEventArgs e)
        {
            using (Font titleFont =
                new Font("Arial", 15, FontStyle.Bold))
            using (Font normalFont =
                new Font("Arial", 9))
            using (Font boldFont =
                new Font("Arial", 9, FontStyle.Bold))
            {
                Graphics g = e.Graphics;

                float x = e.MarginBounds.Left;
                float width = e.MarginBounds.Width;
                float y = e.MarginBounds.Top;
                float line = 19f;

                DrawCentered(
                    g, "RenOrPOS", titleFont, x, width, y);

                y += 28;

                DrawCentered(
                    g, "SALES RECEIPT",
                    boldFont, x, width, y);

                y += 27;

                g.DrawString(
                    "Receipt #: " + saleId.ToString("D6"),
                    normalFont, Brushes.Black, x, y);

                y += line;

                g.DrawString(
                    "Date: " +
                    saleDate.ToString("MMM dd, yyyy hh:mm tt"),
                    normalFont, Brushes.Black, x, y);

                y += line;

                g.DrawString(
                    "Cashier: " + cashier,
                    normalFont, Brushes.Black, x, y);

                y += line;

                g.DrawString(
                    "Payment: " + paymentMethod,
                    normalFont, Brushes.Black, x, y);

                y += 27;

                g.DrawLine(
                    Pens.Black, x, y, x + width, y);

                y += 15;

                foreach (DataRow row in items.Rows)
                {
                    string name = Convert.ToString(
                        row["ProductName"]);

                    int quantity = Convert.ToInt32(
                        row["Quantity"]);

                    decimal price = Convert.ToDecimal(
                        row["UnitPrice"]);

                    decimal subtotal = Convert.ToDecimal(
                        row["Subtotal"]);

                    RectangleF nameArea = new RectangleF(
                        x, y, width, 45);

                    g.DrawString(
                        name, normalFont,
                        Brushes.Black, nameArea);

                    y += 42;

                    g.DrawString(
                        quantity + " x " +
                        price.ToString("N2"),
                        normalFont, Brushes.Black, x, y);

                    using (StringFormat right =
                        new StringFormat())
                    {
                        right.Alignment =
                            StringAlignment.Far;

                        g.DrawString(
                            subtotal.ToString("N2"),
                            normalFont,
                            Brushes.Black,
                            new RectangleF(
                                x, y, width, line),
                            right);
                    }

                    y += 28;
                }

                g.DrawLine(
                    Pens.Black, x, y, x + width, y);

                y += 20;

                DrawAmount(
                    g, "TOTAL:", total,
                    boldFont, x, width, y);

                y += line;

                DrawAmount(
                    g, "PAID:", paid,
                    normalFont, x, width, y);

                y += line;

                DrawAmount(
                    g, "CHANGE:", change,
                    normalFont, x, width, y);

                y += 42;

                DrawCentered(
                    g, "Thank you for shopping!",
                    normalFont, x, width, y);

                e.HasMorePages = false;
            }
        }

        private static void DrawCentered(
            Graphics g,
            string text,
            Font font,
            float x,
            float width,
            float y)
        {
            using (StringFormat format =
                new StringFormat())
            {
                format.Alignment =
                    StringAlignment.Center;

                g.DrawString(
                    text,
                    font,
                    Brushes.Black,
                    new RectangleF(x, y, width, 30),
                    format);
            }
        }

        private static void DrawAmount(
            Graphics g,
            string label,
            decimal amount,
            Font font,
            float x,
            float width,
            float y)
        {
            g.DrawString(
                label, font, Brushes.Black, x, y);

            using (StringFormat format =
                new StringFormat())
            {
                format.Alignment =
                    StringAlignment.Far;

                g.DrawString(
                    amount.ToString("N2"),
                    font,
                    Brushes.Black,
                    new RectangleF(x, y, width, 22),
                    format);
            }
        }
    }
}
