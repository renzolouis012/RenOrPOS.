﻿
using System;
using System.Windows.Forms;
using RenOrPOS.Services;

namespace RenOrPOS.WinForms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void chkShowPassword_CheckedChanged(
            object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar =
                !chkShowPassword.Checked;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show(
                    "Please enter your username and password.");
                return;
            }

            try
            {
                AuthService auth = new AuthService();

                if (!auth.Login(username, password))
                {
                    MessageBox.Show(
                        "Invalid credentials or inactive account.",
                        "Login Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    txtPassword.Clear();
                    txtPassword.Focus();
                    return;
                }

                string role = auth.LoggedInRole;
                int userId = auth.LoggedInUserId;

                Form nextForm;

                if (string.Equals(
                    role, "Cashier",
                    StringComparison.OrdinalIgnoreCase))
                {
                    nextForm = new POSForm(userId);
                }
                else if (
                    string.Equals(role, "Admin",
                        StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(role, "Manager",
                        StringComparison.OrdinalIgnoreCase))
                {
                    nextForm = new DashboardForm(role, userId);
                }
                else
                {
                    MessageBox.Show("Unsupported user role.");
                    return;
                }

                this.Hide();

                nextForm.FormClosed += (s, args) =>
                {
                    txtUsername.Clear();
                    txtPassword.Clear();

                    this.Show();
                    this.Activate();
                };

                nextForm.Show();
            }
            catch (Exception ex)
            {
                this.Show();

                MessageBox.Show(
                    "Login error: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
