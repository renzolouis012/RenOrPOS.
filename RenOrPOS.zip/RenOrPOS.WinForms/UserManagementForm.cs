﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class UserManagementForm : Form
    {
        private int selectedUserId = 0;
        private bool selectedUserActive = false;

        public UserManagementForm()
        {
            InitializeComponent();

            // Connect button events
            btnAdd.Click += btnAdd_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDeactivate.Click += btnDeactivate_Click;
            btnActivate.Click += btnActivate_Click;
            btnResetPassword.Click += btnResetPassword_Click;
            btnClear.Click += btnClear_Click;

            // Connect DataGridView selection event
            dgvUsers.CellClick += dgvUsers_CellClick;

            LoadRoles();
            LoadUsers();
            ClearFields();
        }

        // =========================================
        // LOAD ROLES
        // =========================================
        private void LoadRoles()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    string query = @"
                        SELECT RoleId, RoleName
                        FROM dbo.Roles
                        ORDER BY RoleId";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(query, con))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        cmbRole.DisplayMember = "RoleName";
                        cmbRole.ValueMember = "RoleId";
                        cmbRole.DataSource = dt;
                        cmbRole.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Failed to load roles", ex);
            }
        }

        // =========================================
        // LOAD USERS
        // =========================================
        private void LoadUsers()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_User_List", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    DataTable dt = new DataTable();

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }

                    dgvUsers.DataSource = dt;

                    if (dgvUsers.Columns.Contains("RoleId"))
                        dgvUsers.Columns["RoleId"].Visible = false;

                    if (dgvUsers.Columns.Contains("UserId"))
                        dgvUsers.Columns["UserId"].HeaderText = "User ID";

                    if (dgvUsers.Columns.Contains("FullName"))
                        dgvUsers.Columns["FullName"].HeaderText = "Full Name";

                    if (dgvUsers.Columns.Contains("RoleName"))
                        dgvUsers.Columns["RoleName"].HeaderText = "Role";

                    if (dgvUsers.Columns.Contains("IsActive"))
                        dgvUsers.Columns["IsActive"].HeaderText = "Active";

                    dgvUsers.ClearSelection();
                }
            }
            catch (Exception ex)
            {
                ShowError("Failed to load users", ex);
            }
        }

        // =========================================
        // VALIDATE ACCOUNT FIELDS
        // =========================================
        private bool ValidateUserFields()
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtFullName.Text) ||
                cmbRole.SelectedIndex == -1)
            {
                MessageBox.Show(
                    "Please enter username, full name, and role.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        // =========================================
        // ADD USER
        // =========================================
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateUserFields())
                return;

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show(
                    "Please enter a password for the new user.");
                return;
            }

            if (txtPassword.Text.Length < 8)
            {
                MessageBox.Show(
                    "Password must contain at least 8 characters.");
                return;
            }

            if (MessageBox.Show(
                "Create this user account?",
                "Confirm Add",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                string hash;
                string salt;

                PasswordHasher.HashPassword(
                    txtPassword.Text,
                    out hash,
                    out salt);

                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_User_Insert", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@Username", SqlDbType.NVarChar, 50).Value =
                        txtUsername.Text.Trim();

                    cmd.Parameters.Add(
                        "@PasswordHash", SqlDbType.VarChar, 256).Value =
                        hash;

                    cmd.Parameters.Add(
                        "@Salt", SqlDbType.VarChar, 128).Value =
                        salt;

                    cmd.Parameters.Add(
                        "@FullName", SqlDbType.NVarChar, 100).Value =
                        txtFullName.Text.Trim();

                    cmd.Parameters.Add(
                        "@RoleId", SqlDbType.Int).Value =
                        Convert.ToInt32(cmbRole.SelectedValue);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "User account created successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadUsers();
                ClearFields();
            }
            catch (Exception ex)
            {
                ShowError("Failed to add user", ex);
            }
        }

        // =========================================
        // UPDATE USER
        // =========================================
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!CheckSelectedUser())
                return;

            if (!ValidateUserFields())
                return;

            if (MessageBox.Show(
                "Update this user account?",
                "Confirm Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_User_Update", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@UserId", SqlDbType.Int).Value =
                        selectedUserId;

                    cmd.Parameters.Add(
                        "@Username", SqlDbType.NVarChar, 50).Value =
                        txtUsername.Text.Trim();

                    cmd.Parameters.Add(
                        "@FullName", SqlDbType.NVarChar, 100).Value =
                        txtFullName.Text.Trim();

                    cmd.Parameters.Add(
                        "@RoleId", SqlDbType.Int).Value =
                        Convert.ToInt32(cmbRole.SelectedValue);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "User updated successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadUsers();
                ClearFields();
            }
            catch (Exception ex)
            {
                ShowError("Failed to update user", ex);
            }
        }

        // =========================================
        // DEACTIVATE USER
        // =========================================
        private void btnDeactivate_Click(object sender, EventArgs e)
        {
            if (!CheckSelectedUser())
                return;

            if (!selectedUserActive)
            {
                MessageBox.Show("This account is already inactive.");
                return;
            }

            if (!CanChangeAccountStatus(false))
                return;

            if (MessageBox.Show(
                "Deactivate this account? The user will no longer be able to log in.",
                "Confirm Deactivation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            SetUserActive(false);
        }

        // =========================================
        // ACTIVATE USER
        // =========================================
        private void btnActivate_Click(object sender, EventArgs e)
        {
            if (!CheckSelectedUser())
                return;

            if (selectedUserActive)
            {
                MessageBox.Show("This account is already active.");
                return;
            }

            if (MessageBox.Show(
                "Activate this user account?",
                "Confirm Activation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            SetUserActive(true);
        }

        private void SetUserActive(bool isActive)
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_User_SetActive", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@UserId", SqlDbType.Int).Value =
                        selectedUserId;

                    cmd.Parameters.Add(
                        "@IsActive", SqlDbType.Bit).Value =
                        isActive;

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    isActive
                        ? "User activated successfully!"
                        : "User deactivated successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadUsers();
                ClearFields();
            }
            catch (Exception ex)
            {
                ShowError("Failed to change user status", ex);
            }
        }

        // =========================================
        // RESET PASSWORD
        // =========================================
        private void btnResetPassword_Click(
            object sender, EventArgs e)
        {
            if (!CheckSelectedUser())
                return;

            if (string.IsNullOrWhiteSpace(txtPassword.Text) ||
                txtPassword.Text.Length < 8)
            {
                MessageBox.Show(
                    "Enter a new password with at least 8 characters.");
                return;
            }

            if (MessageBox.Show(
                "Reset password for the selected user?",
                "Confirm Password Reset",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                string hash;
                string salt;

                PasswordHasher.HashPassword(
                    txtPassword.Text,
                    out hash,
                    out salt);

                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(
                    "dbo.usp_User_ResetPassword", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(
                        "@UserId", SqlDbType.Int).Value =
                        selectedUserId;

                    cmd.Parameters.Add(
                        "@PasswordHash", SqlDbType.VarChar, 256).Value =
                        hash;

                    cmd.Parameters.Add(
                        "@Salt", SqlDbType.VarChar, 128).Value =
                        salt;

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(
                    "Password reset successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                ClearFields();
            }
            catch (Exception ex)
            {
                ShowError("Failed to reset password", ex);
            }
        }

        // =========================================
        // SELECT USER FROM DATAGRIDVIEW
        // =========================================
        private void dgvUsers_CellClick(
            object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvUsers.Rows[e.RowIndex];

            if (row.IsNewRow)
                return;

            try
            {
                selectedUserId =
                    Convert.ToInt32(row.Cells["UserId"].Value);

                txtUsername.Text =
                    Convert.ToString(row.Cells["Username"].Value);

                txtFullName.Text =
                    Convert.ToString(row.Cells["FullName"].Value);

                cmbRole.SelectedValue =
                    Convert.ToInt32(row.Cells["RoleId"].Value);

                selectedUserActive =
                    Convert.ToBoolean(row.Cells["IsActive"].Value);

                // Never display stored passwords
                txtPassword.Clear();
            }
            catch (Exception ex)
            {
                ShowError("Failed to select user", ex);
            }
        }

        // =========================================
        // PREVENT LAST ADMIN DEACTIVATION
        // =========================================
        private bool CanChangeAccountStatus(bool activating)
        {
            if (activating)
                return true;

            try
            {
                using (SqlConnection con = Db.GetConnection())
                using (SqlCommand cmd = new SqlCommand(@"
                    SELECT COUNT(*)
                    FROM dbo.Users u
                    INNER JOIN dbo.Roles r
                        ON u.RoleId = r.RoleId
                    WHERE r.RoleName = 'Admin'
                      AND u.IsActive = 1", con))
                {
                    con.Open();

                    int activeAdmins =
                        Convert.ToInt32(cmd.ExecuteScalar());

                    int selectedRoleId =
                        Convert.ToInt32(cmbRole.SelectedValue);

                    // Admin RoleId = 1 in your database
                    if (selectedRoleId == 1 && activeAdmins <= 1)
                    {
                        MessageBox.Show(
                            "You cannot deactivate the last active Admin.",
                            "Security",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                ShowError("Failed to verify Admin accounts", ex);
                return false;
            }
        }

        // =========================================
        // VALIDATE SELECTION
        // =========================================
        private bool CheckSelectedUser()
        {
            if (selectedUserId == 0)
            {
                MessageBox.Show(
                    "Please select a user from the table first.",
                    "Validation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        // =========================================
        // CLEAR FIELDS
        // =========================================
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            selectedUserId = 0;
            selectedUserActive = false;

            txtUsername.Clear();
            txtFullName.Clear();
            txtPassword.Clear();

            cmbRole.SelectedIndex = -1;

            dgvUsers.ClearSelection();

            txtUsername.Focus();
        }

        // =========================================
        // ERROR MESSAGE
        // =========================================
        private void ShowError(string message, Exception ex)
        {
            MessageBox.Show(
                message + ": " + ex.Message,
                "Database Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        private void btnUserManagement_Click(object sender, EventArgs e)
        {
            UserManagementForm form = new UserManagementForm();
            form.ShowDialog();
        }
    }
}
