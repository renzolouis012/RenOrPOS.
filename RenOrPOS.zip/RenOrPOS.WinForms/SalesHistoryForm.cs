﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using RenOrPOS.Data;

namespace RenOrPOS.WinForms
{
    public partial class SalesHistoryForm : Form
    {
        private DataTable salesTable;

        public SalesHistoryForm(string role)
        {
            if (!string.Equals(
                role, "Admin",
                StringComparison.OrdinalIgnoreCase)
                &&
                !string.Equals(
                    role, "Manager",
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new UnauthorizedAccessException(
                    "Admin or Manager access required.");
            }

            InitializeComponent();

            dtpFrom.Value = DateTime.Today.AddDays(-30);
            dtpTo.Value = DateTime.Today;

            txtSearch.TextChanged +=
                (s, e) => ApplyFilters();

            chkDateFilter.CheckedChanged +=
                (s, e) => ApplyFilters();

            dtpFrom.ValueChanged +=
                (s, e) => ApplyFilters();

            dtpTo.ValueChanged +=
                (s, e) => ApplyFilters();

            dgvSales.SelectionChanged +=
                (s, e) => ShowSelectedSale();

            LoadSales();
        }

        // =====================================
        // LOAD SALES
        // =====================================
        private void LoadSales()
        {
            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    string query = @"
                        SELECT
                            s.SaleId,
                            s.SaleDate,
                            u.Username AS Cashier,
                            s.TotalAmount,
                            s.AmountPaid,
                            s.ChangeAmount,
                            s.PaymentMethod
                        FROM dbo.Sales s
                        INNER JOIN dbo.Users u
                            ON s.CashierId = u.UserId
                        ORDER BY s.SaleDate DESC, s.SaleId DESC";

                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(query, con))
                    {
                        salesTable = new DataTable();
                        adapter.Fill(salesTable);
                    }
                }

                dgvSales.DataSource =
                    salesTable.DefaultView;

                if (dgvSales.Columns.Contains("SaleId"))
                    dgvSales.Columns["SaleId"].HeaderText =
                        "Sale ID";

                if (dgvSales.Columns.Contains("SaleDate"))
                {
                    dgvSales.Columns["SaleDate"].HeaderText =
                        "Date / Time";

                    dgvSales.Columns["SaleDate"]
                        .DefaultCellStyle.Format =
                        "MMM dd, yyyy hh:mm tt";

                    dgvSales.Columns["SaleDate"]
                        .FillWeight = 150;
                }

                foreach (string name in new[]
                {
                    "TotalAmount",
                    "AmountPaid",
                    "ChangeAmount"
                })
                {
                    if (dgvSales.Columns.Contains(name))
                        dgvSales.Columns[name]
                            .DefaultCellStyle.Format = "N2";
                }

                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Failed to load sales:\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // =====================================
        // SEARCH AND DATE FILTER
        // =====================================
        private void ApplyFilters()
        {
            if (salesTable == null)
                return;

            if (chkDateFilter.Checked &&
                dtpFrom.Value.Date > dtpTo.Value.Date)
            {
                salesTable.DefaultView.RowFilter =
                    "1 = 0";

                dgvSaleItems.DataSource = null;

                lblSummary.Text =
                    "From date cannot be later than To date.";

                return;
            }

            string search = txtSearch.Text.Trim()
                .Replace("'", "''")
                .Replace("[", "[[]")
                .Replace("%", "[%]")
                .Replace("*", "[*]");

            string filter =
                "(Convert(SaleId, 'System.String') LIKE '%" +
                search +
                "%' OR Cashier LIKE '%" +
                search + "%')";

            if (chkDateFilter.Checked)
            {
                filter +=
                    " AND SaleDate >= #" +
                    dtpFrom.Value.Date.ToString("MM/dd/yyyy") +
                    "# AND SaleDate < #" +
                    dtpTo.Value.Date.AddDays(1)
                        .ToString("MM/dd/yyyy") +
                    "#";
            }

            try
            {
                salesTable.DefaultView.RowFilter = filter;
            }
            catch (EvaluateException)
            {
                salesTable.DefaultView.RowFilter = "1 = 0";
            }

            ShowSelectedSale();
        }

        // =====================================
        // SELECT SALE AND LOAD ITEMS
        // =====================================
        private void ShowSelectedSale()
        {
            DataRowView selected =
                dgvSales.CurrentRow == null
                ? null
                : dgvSales.CurrentRow.DataBoundItem
                    as DataRowView;

            if (selected == null)
            {
                dgvSaleItems.DataSource = null;
                lblSummary.Text = "No sale selected.";
                return;
            }

            int saleId =
                Convert.ToInt32(selected["SaleId"]);

            try
            {
                using (SqlConnection con = Db.GetConnection())
                {
                    con.Open();

                    string query = @"
                        SELECT
                            p.Name AS ProductName,
                            si.Quantity,
                            si.UnitPrice,
                            si.Subtotal
                        FROM dbo.SaleItems si
                        INNER JOIN dbo.Products p
                            ON si.ProductId = p.ProductId
                        WHERE si.SaleId = @SaleId
                        ORDER BY si.SaleItemId";

                    using (SqlCommand cmd =
                        new SqlCommand(query, con))
                    {
                        cmd.Parameters.Add(
                            "@SaleId", SqlDbType.Int)
                            .Value = saleId;

                        using (SqlDataAdapter adapter =
                            new SqlDataAdapter(cmd))
                        {
                            DataTable details =
                                new DataTable();

                            adapter.Fill(details);

                            dgvSaleItems.DataSource = details;
                        }
                    }
                }

                if (dgvSaleItems.Columns.Contains("ProductName"))
                    dgvSaleItems.Columns["ProductName"]
                        .HeaderText = "Product";

                foreach (string name in new[]
                {
                    "UnitPrice",
                    "Subtotal"
                })
                {
                    if (dgvSaleItems.Columns.Contains(name))
                        dgvSaleItems.Columns[name]
                            .DefaultCellStyle.Format = "N2";
                }

                lblSummary.Text =
                    "Sale #" + saleId +
                    "     Total: ₱" +
                    Convert.ToDecimal(
                        selected["TotalAmount"]).ToString("N2") +
                    "     Paid: ₱" +
                    Convert.ToDecimal(
                        selected["AmountPaid"]).ToString("N2") +
                    "     Change: ₱" +
                    Convert.ToDecimal(
                        selected["ChangeAmount"]).ToString("N2");
            }
            catch (Exception ex)
            {
                dgvSaleItems.DataSource = null;

                lblSummary.Text =
                    "Unable to load sale details.";

                MessageBox.Show(
                    "Failed to load sale items:\n" +
                    ex.Message);
            }
        }

        // =====================================
        // NEW: PRINT SELECTED RECEIPT
        // =====================================
        private void btnPrintReceipt_Click(
            object sender, EventArgs e)
        {
            DataRowView selected =
                dgvSales.CurrentRow == null
                ? null
                : dgvSales.CurrentRow.DataBoundItem
                    as DataRowView;

            if (selected == null)
            {
                MessageBox.Show(
                    "Please select a sale first.");
                return;
            }

            int saleId =
                Convert.ToInt32(selected["SaleId"]);

            try
            {
                ReceiptService receipt =
                    new ReceiptService();

                receipt.PrintReceipt(saleId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Receipt could not be opened:\n" +
                    ex.Message,
                    "Receipt Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // =====================================
        // REFRESH
        // =====================================
        private void btnRefresh_Click(
            object sender, EventArgs e)
        {
            LoadSales();
        }

        // =====================================
        // CLOSE
        // =====================================
        private void btnClose_Click(
            object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
