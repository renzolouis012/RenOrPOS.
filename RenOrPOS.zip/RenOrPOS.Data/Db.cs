﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace RenOrPOS.Data
{
    public static class Db
    {
        public static string ConnectionString =
            @"Data Source=.\SQLEXPRESS;Initial Catalog=ortega;Integrated Security=True;TrustServerCertificate=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}