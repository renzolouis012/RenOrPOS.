﻿
using System;
using System.Data;
using System.Data.SqlClient;
using RenOrPOS.Data;

namespace RenOrPOS.Services
{
    public class AuthService
    {
        public int LoggedInUserId { get; private set; }
        public string LoggedInRole { get; private set; }
        public string LoggedInUsername { get; private set; }

        public bool Login(string username, string password)
        {
            LoggedInUserId = 0;
            LoggedInRole = null;
            LoggedInUsername = null;

            using (SqlConnection con = Db.GetConnection())
            {
                con.Open();

                string query = @"
                    SELECT
                        u.UserId,
                        u.Username,
                        u.PasswordHash,
                        u.Salt,
                        u.IsActive,
                        r.RoleName
                    FROM dbo.Users u
                    INNER JOIN dbo.Roles r
                        ON u.RoleId = r.RoleId
                    WHERE u.Username = @Username";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.Add(
                        "@Username", SqlDbType.NVarChar, 50)
                        .Value = username;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                            return false;

                        if (!Convert.ToBoolean(reader["IsActive"]))
                            return false;

                        bool valid = PasswordHasher.VerifyPassword(
                            password,
                            reader["PasswordHash"].ToString(),
                            reader["Salt"].ToString());

                        if (!valid)
                            return false;

                        LoggedInUserId =
                            Convert.ToInt32(reader["UserId"]);

                        LoggedInUsername =
                            reader["Username"].ToString();

                        LoggedInRole =
                            reader["RoleName"].ToString();

                        return true;
                    }
                }
            }
        }
    }
}
